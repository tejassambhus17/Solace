import React, { useMemo } from "react";
import { StyleSheet, useWindowDimensions, View } from "react-native";
import {
  habitGardenStages,
  habitInsights,
  habitWeekStart,
  type Habit,
} from "../../server/src/habit-contract";
import {
  GardenScene,
  gardenLabels,
  habitToday,
  useHabitClock,
} from "../habits-ui";
import { spacing } from "../layout";
import { useApp } from "../store";
import { useTheme } from "../theme";
import { AppText, BotanicalBackdrop, Button, Card, Icon, Row } from "../ui";

const stageIcons = [
  "ellipse-outline",
  "leaf-outline",
  "git-branch-outline",
  "flower-outline",
  "flower",
] as const;
const noHabits: Habit[] = [];
const earnedStages = habitGardenStages.filter(({ minimum }) => minimum > 0);

export function HabitsGardenSection({
  onBackToToday,
  active,
}: {
  onBackToToday: () => void;
  active: boolean;
}) {
  const app = useApp();
  const { colors, resolved } = useTheme();
  const peachInk = resolved === "dark" ? colors.peach : colors.peachText;
  const milestoneInk =
    resolved === "dark" ? colors.lavender : colors.lavenderText;
  const { width, fontScale } = useWindowDimensions();
  const habits = app.data.habits;
  const now = useHabitClock(active ? habits : noHabits);
  const today = habitToday(undefined, now);
  const weekStart = habitWeekStart(today);
  const weekly = useMemo(
    () =>
      habitInsights(
        active ? habits : noHabits,
        active ? app.data.habitProgress : [],
        weekStart,
        today,
        today,
        now,
      ),
    [active, habits, app.data.habitProgress, weekStart, today, now],
  );
  const garden = app.data.habitGarden[0];
  const stage = garden?.stage ?? "seed";
  const earned = garden?.earnedTotal ?? 0;
  const milestones = earnedStages.filter(
    ({ minimum }) => earned >= minimum,
  ).length;
  const total = earnedStages.length;
  const progress = Math.round((milestones * 100) / total);
  const next = habitGardenStages.find(({ minimum }) => minimum > earned);
  const fixedSchedule = habits.some((habit) =>
    habit.revisions.some(
      ({ status, schedule }) =>
        status === "active" && schedule.type !== "weekly",
    ),
  );
  const stack = width < 340 || fontScale >= 1.45;
  const stats = [
    {
      icon: "calendar-outline",
      value: `${weekly.daysWithCompletion}/7`,
      label: "Days this week",
    },
    {
      icon: "flame-outline",
      value: fixedSchedule ? String(weekly.currentStreak) : "—",
      label: "Day streak",
    },
    {
      icon: "leaf-outline",
      value: String(habits.filter(({ status }) => status === "active").length),
      label: "Habits active",
    },
  ];

  return (
    <View style={styles.page}>
      <GardenScene stage={stage} />
      <Card style={styles.card}>
        <Row style={styles.progressRow}>
          <Icon name="leaf-outline" color={colors.lavenderText} size={21} />
          <View style={styles.copy}>
            <AppText variant="label">Garden Progress</AppText>
            <AppText variant="caption" color={colors.muted}>
              {milestones} of {total} milestones
            </AppText>
          </View>
          <View style={[styles.pill, { backgroundColor: colors.sageSurface }]}>
            <AppText variant="label" color={colors.sageText}>
              {progress}%
            </AppText>
          </View>
        </Row>
        <View
          accessible
          accessibilityRole="progressbar"
          accessibilityLabel="Garden milestones"
          accessibilityValue={{ min: 0, max: total, now: milestones }}
          style={styles.segments}
        >
          {earnedStages.map((item, index) => (
            <View
              key={item.stage}
              aria-hidden
              style={[
                styles.segment,
                {
                  backgroundColor:
                    index < milestones ? milestoneInk : colors.border,
                },
              ]}
            />
          ))}
        </View>
        <AppText variant="caption" color={colors.muted}>
          {next
            ? `${next.minimum - earned} more ${next.minimum - earned === 1 ? "completion" : "completions"} to ${gardenLabels[next.stage].toLowerCase()}.`
            : "Your garden has reached its final stage."}
        </AppText>
      </Card>
      <Card style={[styles.card, stack && styles.wrappedCard]}>
        <View style={[styles.timeline, stack && styles.wrappedTimeline]}>
          {!stack && (
            <View
              aria-hidden
              style={[styles.timelineRule, { backgroundColor: colors.border }]}
            />
          )}
          {habitGardenStages.map((item, index) => {
            const current = item.stage === stage;
            const reached = earned >= item.minimum;
            const ink = current
              ? peachInk
              : reached
                ? colors.lavenderText
                : colors.muted;
            return (
              <View
                key={item.stage}
                accessible
                accessibilityLabel={`${gardenLabels[item.stage]}, ${current ? "current stage" : reached ? "reached" : `${item.minimum} habit completions required`}`}
                style={[styles.timelineItem, stack && styles.wrappedStage]}
              >
                <Icon name={stageIcons[index]} color={ink} size={24} />
                <View
                  aria-hidden
                  style={[
                    styles.dot,
                    {
                      borderColor: ink,
                      backgroundColor: reached ? ink : colors.surface,
                    },
                  ]}
                />
                <AppText
                  variant="caption"
                  style={styles.centered}
                  color={current ? colors.text : colors.muted}
                >
                  {gardenLabels[item.stage]}
                </AppText>
                {current && (
                  <AppText variant="caption" color={colors.sageText}>
                    Current
                  </AppText>
                )}
              </View>
            );
          })}
        </View>
      </Card>
      <Card style={[styles.card, styles.howCard]}>
        <BotanicalBackdrop />
        <Row style={styles.howRow}>
          <Icon name="sparkles-outline" color={peachInk} size={22} />
          <View style={styles.copy}>
            <AppText variant="heading">How it works</AppText>
            <AppText color={colors.muted} variant="caption">
              Each completed habit day grows your garden. That growth stays with
              you through pauses and missed days.
            </AppText>
          </View>
        </Row>
      </Card>
      <Card style={[styles.card, styles.stats, stack && styles.stackedStats]}>
        {stats.map(({ icon, label, value }, index) => (
          <View
            key={label}
            style={[
              styles.stat,
              stack && styles.stackedStat,
              !stack &&
                index > 0 && { borderLeftWidth: 1, borderColor: colors.border },
            ]}
          >
            <Icon name={icon} color={peachInk} size={22} />
            <AppText variant="heading" color={colors.lavenderText}>
              {value}
            </AppText>
            <AppText
              variant="caption"
              color={colors.muted}
              style={styles.centered}
            >
              {label}
            </AppText>
          </View>
        ))}
      </Card>
      <Button
        title="Back to Habits"
        icon="arrow-back-outline"
        onPress={onBackToToday}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  page: { gap: spacing.row },
  card: { padding: spacing.row, borderRadius: 18, gap: spacing.compact },
  progressRow: { alignItems: "flex-start" },
  copy: { flex: 1, minWidth: 0, gap: 3 },
  pill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 14 },
  segments: { flexDirection: "row", gap: 4 },
  segment: { height: 9, borderRadius: 8, flex: 1 },
  timeline: { flexDirection: "row", alignItems: "flex-start", gap: 2 },
  timelineRule: {
    position: "absolute",
    top: 34,
    left: "10%",
    right: "10%",
    height: StyleSheet.hairlineWidth,
  },
  timelineItem: { flex: 1, minWidth: 0, alignItems: "center", gap: 4 },
  wrappedCard: { gap: 4 },
  wrappedTimeline: { flexWrap: "wrap", rowGap: spacing.row },
  wrappedStage: { flexGrow: 1, flexBasis: "31%" },
  dot: { height: 12, width: 12, borderRadius: 6, borderWidth: 1 },
  centered: { textAlign: "center" },
  howCard: { overflow: "hidden" },
  howRow: { alignItems: "flex-start" },
  stats: { flexDirection: "row", gap: 0 },
  stat: {
    flex: 1,
    minWidth: 0,
    gap: 3,
    alignItems: "center",
    paddingHorizontal: 4,
  },
  stackedStats: { flexDirection: "column", gap: spacing.row },
  stackedStat: {
    flexDirection: "row",
    gap: spacing.compact,
    justifyContent: "center",
  },
});
