import React, { useMemo, useState } from "react";
import { Pressable, StyleSheet, View, useWindowDimensions } from "react-native";
import {
  addHabitDays,
  habitGardenStages,
  habitInsights,
  habitRevisionOn,
  habitTarget,
  habitWeekStart,
  isHabitScheduled,
} from "../../server/src/habit-contract";
import {
  displayHabitDay,
  GardenScene,
  gardenLabels,
  goalLabel,
  HabitChoice,
  HabitIconBadge,
  HabitMeter,
  HabitWeekStrip,
  habitToday,
  occurrenceLabel,
  scheduleLabel,
  starterHabits,
  useHabitClock,
} from "../habits-ui";
import { spacing } from "../layout";
import { routes } from "../routes";
import { useApp } from "../store";
import { useTheme } from "../theme";
import { AppText, Button, Card, Icon } from "../ui";
import {
  HabitLogAction,
  HabitProgressRing,
  useHabitLog,
  useHabitOccurrences,
} from "./HabitsSectionPieces";

type Period = "week" | "month";
type Occurrence = ReturnType<typeof useHabitOccurrences>["all"][number];
const rowLimit = 8;
const gardenMilestones = habitGardenStages.filter(({ minimum }) => minimum > 0);
const numberOfDays = (start: string, end: string) =>
  Math.round((Date.parse(end) - Date.parse(start)) / 86_400_000) + 1;

function monthStart(day: string, offset: number) {
  const date = new Date(`${day.slice(0, 7)}-01T12:00:00Z`);
  date.setUTCMonth(date.getUTCMonth() + offset);
  return date.toISOString().slice(0, 10);
}

function SectionTitle({ title, icon }: { title: string; icon: string }) {
  const { colors } = useTheme();
  return (
    <View style={styles.titleGroup}>
      <Icon name={icon} color={colors.sageText} size={21} />
      <AppText accessibilityRole="header" variant="heading" style={styles.wrap}>
        {title}
      </AppText>
    </View>
  );
}

function TodayHabitRow({ occurrence }: { occurrence: Occurrence }) {
  const app = useApp();
  const { colors, resolved } = useTheme();
  const { habit, day, log, logs } = occurrence;
  const { write, pending, error } = useHabitLog(occurrence);
  const revision = habitRevisionOn(habit, day);
  const goal = revision?.goal ?? habit.goal;
  const details =
    revision?.schedule.type === "weekly"
      ? scheduleLabel(revision.schedule)
      : revision?.schedule.type === "daily"
        ? "Daily"
        : scheduleLabel(revision?.schedule ?? habit.schedule);
  const weekStart = habitWeekStart(day);
  const weekCompletions =
    revision?.schedule.type === "weekly"
      ? logs.filter(
          (item) =>
            item.complete &&
            item.day >= weekStart &&
            item.day <= day &&
            habitRevisionOn(habit, item.day)?.schedule.type === "weekly" &&
            isHabitScheduled(habit, item.day),
        ).length
      : undefined;
  const progress = occurrenceLabel(habit, day, log);
  const open = () => app.navigate(routes.habitDetails, { id: habit.id });
  return (
    <Card
      style={[
        styles.habitRow,
        {
          backgroundColor:
            resolved === "dark" ? colors.surface : colors.lavenderSurface,
        },
      ]}
    >
      <View style={styles.row}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Open ${habit.name}`}
          accessibilityHint={progress}
          onPress={open}
          style={({ pressed }) => [styles.identity, pressed && styles.pressed]}
        >
          <HabitIconBadge icon={habit.icon} color={habit.color} size={42} />
          <View style={styles.fill}>
            <AppText variant="label">{habit.name}</AppText>
            <AppText variant="caption" color={colors.muted}>
              {details} · {goalLabel(goal)}
            </AppText>
          </View>
        </Pressable>
        {habit.status === "active" ? (
          <HabitLogAction
            occurrence={occurrence}
            disabled={pending}
            onLog={write}
          />
        ) : (
          <AppText variant="caption" color={colors.muted} style={styles.wrap}>
            {habit.status === "paused" ? "Paused" : "Archived"}
          </AppText>
        )}
      </View>
      {goal.type !== "completion" && (
        <View style={styles.smallGap}>
          <HabitMeter
            value={log?.amount ?? 0}
            total={log?.target ?? habitTarget(goal)}
            label={`Today's progress for ${habit.name}`}
          />
          <AppText variant="caption" color={colors.muted}>
            {progress}
          </AppText>
        </View>
      )}
      {weekCompletions !== undefined &&
        revision?.schedule.type === "weekly" && (
          <AppText variant="caption" color={colors.muted}>
            {weekCompletions > revision.schedule.daysPerWeek
              ? `${weekCompletions} days completed this week · goal met`
              : `${weekCompletions} of ${revision.schedule.daysPerWeek} days this week`}
          </AppText>
        )}
      {!!error && (
        <AppText
          variant="caption"
          accessibilityRole="alert"
          color={colors.danger}
        >
          {error}
        </AppText>
      )}
    </Card>
  );
}

export function HabitsTodaySection({
  onOpenGarden,
  onOpenInsights,
  onOpenManagement,
}: {
  onOpenGarden: () => void;
  onOpenInsights: (period?: Period) => void;
  onOpenManagement: () => void;
}) {
  const app = useApp();
  const { colors, resolved } = useTheme();
  const { width, fontScale } = useWindowDimensions();
  const { habits, habitProgress, habitGarden } = app.data;
  const now = useHabitClock(habits);
  const today = habitToday(undefined, now);
  const { fixed, flexible, completed } = useHabitOccurrences(
    habits,
    habitProgress,
    now,
  );
  const scheduled = useMemo(
    () =>
      [...fixed].sort(
        (a, b) =>
          Number(!!a.log?.complete) - Number(!!b.log?.complete) ||
          (a.habit.reminderTime ?? "99:99").localeCompare(
            b.habit.reminderTime ?? "99:99",
          ),
      ),
    [fixed],
  );
  const [period, setPeriod] = useState<Period>("week");
  const [limit, setLimit] = useState(rowLimit);
  const [flexibleLimit, setFlexibleLimit] = useState(rowLimit);
  const stackCards = width < 330 || fontScale > 1.3;
  const garden = habitGarden[0];
  const stage = garden?.stage ?? "seed";
  const panel = resolved === "dark" ? colors.surface : colors.lavenderSurface;
  const milestones = gardenMilestones.filter(
    ({ minimum }) => (garden?.earnedTotal ?? 0) >= minimum,
  ).length;
  const scheduleCount = fixed.length;
  const remaining = scheduleCount - completed;
  const flexDone = flexible.filter(({ log }) => log?.complete).length;
  const start =
    period === "week" ? habitWeekStart(today) : monthStart(today, 0);
  const end =
    period === "week"
      ? addHabitDays(start, 6)
      : addHabitDays(monthStart(today, 1), -1);
  const prevStart =
    period === "week" ? addHabitDays(start, -7) : monthStart(today, -1);
  const comparableEnd = addHabitDays(prevStart, numberOfDays(start, today) - 1);
  const previousEnd = comparableEnd < start ? comparableEnd : undefined;
  const { current, previous } = useMemo(
    () => ({
      current: habitInsights(habits, habitProgress, start, end, today, now),
      previous: previousEnd
        ? habitInsights(
            habits,
            habitProgress,
            prevStart,
            previousEnd,
            today,
            now,
          )
        : undefined,
    }),
    [habits, habitProgress, start, end, prevStart, previousEnd, today, now],
  );
  const daysComplete = current.daysWithCompletion;
  const comparison =
    current.scheduled > 0 && previous && previous.scheduled > 0
      ? current.percentage - previous.percentage
      : undefined;
  const weekProgress = useMemo(() => {
    if (period !== "week") return [];
    const days = new Set(
      current.days
        .filter(({ completed }) => completed > 0)
        .map(({ day }) => day),
    );
    return habitProgress.filter(
      ({ day, complete }) => complete && days.has(day),
    );
  }, [current.days, habitProgress, period]);

  return (
    <View style={styles.section}>
      <Card style={[styles.progress, { backgroundColor: panel }]}>
        <View style={styles.heading}>
          <SectionTitle title="Today's Progress" icon="leaf-outline" />
          <View style={styles.date}>
            <Icon name="calendar-outline" size={16} color={colors.muted} />
            <AppText variant="caption" color={colors.muted}>
              {displayHabitDay(today, {
                weekday: "short",
                month: "short",
                day: "numeric",
              })}
            </AppText>
          </View>
        </View>
        {scheduleCount ? (
          <View style={[styles.progressContent, stackCards && styles.stack]}>
            <HabitProgressRing
              value={completed}
              total={scheduleCount}
              size={Math.min(110, Math.round(84 * fontScale))}
              ink={colors.sageText}
              track={colors.border}
            >
              <AppText variant="label" style={styles.ringValue}>
                {completed}/{scheduleCount}
              </AppText>
              <AppText variant="caption" color={colors.muted}>
                Done
              </AppText>
            </HabitProgressRing>
            <View
              style={[
                styles.stats,
                !stackCards && {
                  borderStartWidth: 1,
                  borderColor: colors.border,
                },
              ]}
            >
              {[
                ["checkmark-circle", `${completed} completed`],
                ["ellipse-outline", `${remaining} remaining`],
                ["calendar-outline", `${scheduleCount} scheduled`],
              ].map(([icon, label]) => (
                <View style={styles.stat} key={icon}>
                  <Icon
                    name={icon}
                    color={
                      icon === "checkmark-circle"
                        ? colors.sageText
                        : colors.muted
                    }
                    size={18}
                  />
                  <AppText variant="caption" style={styles.wrap}>
                    {label}
                  </AppText>
                </View>
              ))}
            </View>
          </View>
        ) : (
          <AppText color={colors.muted}>Nothing scheduled today.</AppText>
        )}
        {!!flexible.length && (
          <AppText variant="caption" color={colors.muted}>
            {flexDone} of {flexible.length} flexible habits completed today
          </AppText>
        )}
      </Card>

      <View style={styles.list}>
        <View style={styles.heading}>
          <SectionTitle title="All My Habits" icon="leaf-outline" />
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="View all habits"
            onPress={onOpenManagement}
            style={({ pressed }) => [
              styles.inlineLink,
              pressed && styles.pressed,
            ]}
          >
            <AppText variant="label" color={colors.sageText}>
              View All
            </AppText>
            <Icon name="chevron-forward" size={16} color={colors.sageText} />
          </Pressable>
        </View>
        {!habits.length ? (
          <Card style={styles.smallGap}>
            <AppText variant="label">Begin with one small habit</AppText>
            <AppText variant="caption" color={colors.muted}>
              Choose a starter and make it your own.
            </AppText>
            <View style={styles.choices}>
              {[starterHabits[0], starterHabits[1], starterHabits[4]].map(
                (suggestion) => (
                  <HabitChoice
                    key={suggestion.name}
                    label={suggestion.name}
                    selected={false}
                    onPress={() =>
                      app.navigate(routes.habitCreate, { suggestion })
                    }
                  />
                ),
              )}
            </View>
          </Card>
        ) : (
          <>
            {!scheduleCount && (
              <AppText color={colors.muted}>
                {flexible.length
                  ? "No fixed habits today. Your flexible habits are below."
                  : "No habits are due today."}
              </AppText>
            )}
            {!!scheduleCount && !remaining && (
              <AppText variant="caption" color={colors.sageText}>
                All your scheduled habits are complete for today.
              </AppText>
            )}
            {scheduled.slice(0, limit).map((occurrence) => (
              <TodayHabitRow
                key={`${occurrence.habit.id}:${occurrence.day}`}
                occurrence={occurrence}
              />
            ))}
            {fixed.length > limit && (
              <Button
                title="Show more scheduled habits"
                variant="ghost"
                onPress={() => setLimit(limit + rowLimit)}
              />
            )}
            {!!flexible.length && (
              <View style={styles.list}>
                <AppText variant="label" accessibilityRole="header">
                  Flexible this week
                </AppText>
                {flexible.slice(0, flexibleLimit).map((occurrence) => (
                  <TodayHabitRow
                    key={`${occurrence.habit.id}:${occurrence.day}`}
                    occurrence={occurrence}
                  />
                ))}
                {flexible.length > flexibleLimit && (
                  <Button
                    title="Show more flexible habits"
                    variant="ghost"
                    onPress={() => setFlexibleLimit(flexibleLimit + rowLimit)}
                  />
                )}
              </View>
            )}
          </>
        )}
      </View>

      <Card
        style={[
          styles.garden,
          stackCards && styles.stack,
          { backgroundColor: panel },
        ]}
      >
        <View style={!stackCards && styles.gardenArt}>
          <GardenScene compact stage={stage} />
        </View>
        <View style={[styles.gardenCopy, !stackCards && styles.fill]}>
          <SectionTitle title="Your Growing Garden" icon="leaf-outline" />
          <AppText variant="caption" color={colors.muted}>
            {gardenLabels[stage]} · {milestones} of {gardenMilestones.length}{" "}
            milestones
          </AppText>
          <View style={styles.segments} aria-hidden>
            {gardenMilestones.map((item, index) => (
              <View
                key={item.stage}
                style={[
                  styles.milestone,
                  {
                    backgroundColor:
                      index < milestones ? colors.lavenderText : colors.border,
                  },
                ]}
              />
            ))}
          </View>
          <Button
            title="Open Garden"
            icon="chevron-forward"
            variant="secondary"
            onPress={onOpenGarden}
            style={styles.gardenButton}
          />
        </View>
      </Card>

      <View style={styles.list}>
        <View style={styles.heading}>
          <SectionTitle title="History & Insights" icon="bar-chart-outline" />
          <View style={styles.choices}>
            <HabitChoice
              label="Week"
              selected={period === "week"}
              onPress={() => setPeriod("week")}
            />
            <HabitChoice
              label="Month"
              selected={period === "month"}
              onPress={() => setPeriod("month")}
            />
          </View>
        </View>
        <Card style={[styles.history, { backgroundColor: panel }]}>
          <View style={styles.smallGap}>
            <AppText variant="heading" color={colors.lavenderText}>
              {daysComplete}/{numberOfDays(start, end)} days
            </AppText>
            <AppText variant="caption" color={colors.muted}>
              {daysComplete
                ? `You completed a habit on ${daysComplete} ${daysComplete === 1 ? "day" : "days"} this ${period}.`
                : `Your completed habits this ${period} will appear here.`}
            </AppText>
          </View>
          {period === "week" && (
            <HabitWeekStrip today={today} progress={weekProgress} />
          )}
        </Card>
        <Card
          onPress={() => onOpenInsights(period)}
          accessibilityLabel={`View details for this ${period}`}
          style={[styles.consistency, { backgroundColor: colors.sageSurface }]}
        >
          <Icon name="stats-chart-outline" size={22} color={colors.sageText} />
          <View style={styles.fill}>
            <AppText variant="label">Consistency</AppText>
            <AppText variant="caption" color={colors.muted}>
              {current.scheduled
                ? `${current.percentage}% of goals met this ${period}`
                : `No goals due this ${period} yet`}
            </AppText>
            {comparison !== undefined && (
              <AppText variant="caption" color={colors.sageText}>
                {comparison
                  ? `${comparison > 0 ? "+" : ""}${comparison} points vs. this point last ${period}`
                  : `Same as this point last ${period}`}
              </AppText>
            )}
          </View>
          <View style={styles.inlineLink}>
            <AppText variant="caption" color={colors.sageText}>
              View details
            </AppText>
            <Icon name="chevron-forward" color={colors.sageText} size={17} />
          </View>
        </Card>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  section: { gap: spacing.section },
  list: { gap: spacing.compact },
  smallGap: { gap: spacing.compact },
  fill: { flex: 1, minWidth: 0 },
  wrap: { flexShrink: 1, minWidth: 0 },
  row: { flexDirection: "row", alignItems: "center", gap: spacing.compact },
  heading: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: spacing.compact,
  },
  titleGroup: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.compact,
    flexShrink: 1,
  },
  progress: { borderRadius: 22, padding: spacing.card, gap: spacing.row },
  date: { flexDirection: "row", alignItems: "center", gap: 6, flexShrink: 1 },
  progressContent: {
    flexDirection: "row",
    gap: spacing.card,
    alignItems: "center",
  },
  stack: { flexDirection: "column", alignItems: "stretch" },
  ringValue: { fontSize: 22, lineHeight: 26 },
  stats: { flexGrow: 1, paddingStart: spacing.row, gap: spacing.compact },
  stat: { flexDirection: "row", alignItems: "center", gap: spacing.compact },
  habitRow: {
    borderRadius: 19,
    paddingHorizontal: spacing.row,
    paddingVertical: spacing.compact,
    gap: 6,
  },
  identity: {
    flex: 1,
    minWidth: 0,
    minHeight: 44,
    alignItems: "center",
    flexDirection: "row",
    gap: spacing.row,
  },
  choices: { flexDirection: "row", flexWrap: "wrap", gap: spacing.compact },
  garden: {
    flexDirection: "row",
    borderRadius: 22,
    padding: spacing.compact,
    gap: spacing.row,
  },
  gardenArt: { width: "40%", justifyContent: "center" },
  gardenCopy: { padding: 4, gap: spacing.compact, justifyContent: "center" },
  gardenButton: {
    minHeight: 44,
    alignSelf: "flex-start",
    paddingHorizontal: spacing.row,
  },
  segments: { flexDirection: "row", gap: 4 },
  milestone: { flex: 1, height: 7, borderRadius: 6 },
  history: { padding: spacing.card, gap: spacing.row },
  consistency: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
    gap: spacing.row,
    padding: spacing.row,
  },
  inlineLink: {
    flexDirection: "row",
    alignItems: "center",
    minHeight: 44,
    flexShrink: 1,
    gap: 3,
  },
  pressed: { opacity: 0.74 },
});
