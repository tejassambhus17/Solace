export function formatReminderTime(input: string) {
  const digits = input.replace(/\D/g, "").slice(0, 4);
  return digits.length < 3
    ? digits
    : `${digits.slice(0, 2)}:${digits.slice(2)}`;
}

export function validReminderTime(value: string) {
  return /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value.trim());
}
