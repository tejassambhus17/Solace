export const appActionCapabilityHeader = "X-Solace-App-Actions";

export const appActionDestinations = [
  "today",
  "solace",
  "companion",
  "conversation-history",
  "journal",
  "journal-editor",
  "explore",
  "wellness-tools",
  "ambient-mixer",
  "wellness-toolkit",
  "guided-techniques",
  "guided-programs",
  "wellness-plan",
  "timed-practice",
  "habits",
  "habit-insights",
  "habit-garden",
  "journey",
  "profile",
  "appearance",
  "reminders",
  "memory",
  "support",
  "checkin",
  "moments",
  "daily-pause",
  "habit-library",
  "resources",
  "sleep-guide",
  "grounding",
  "affirmations",
  "saved-affirmations",
  "daily-challenge",
  "reflective-checkins",
  "journey-activity",
  "milestones",
  "personal-goal",
  "account",
  "privacy",
  "about",
] as const;

const themes = ["light", "dark", "system"] as const;
const schedules = ["daily", "weekdays", "weekends"] as const;
const practices = ["breathing", "grounding", "wind-down"] as const;
const practiceMinutes = [5, 10, 15, 20] as const;
const habitPeriods = ["week", "month"] as const;
const progressPeriods = [...habitPeriods, "all"] as const;
const journalDays = ["today", "yesterday"] as const;

const choice = <const T extends readonly (string | number)[]>(choices: T) => ({
  type: typeof choices[0] === "number" ? "integer" : "string",
  enum: choices,
});
const boundedText = { type: "string" } as const;
const appActionFields = {
  navigate: { destination: choice(appActionDestinations) },
  theme: { mode: choice(themes) },
  "habit-create": { name: boundedText, schedule: choice(schedules) },
  "habit-complete": { name: boundedText },
  "reminder-create": {
    title: boundedText,
    time: boundedText,
    repeat: choice(schedules),
  },
  "practice-start": {
    practice: choice(practices),
    minutes: choice(practiceMinutes),
  },
  progress: { period: choice(progressPeriods) },
  "habit-progress": { period: choice(habitPeriods) },
  "journal-search": { when: choice(journalDays) },
  cancel: {},
} as const;

type AppActionKind = keyof typeof appActionFields;
type ActionFields<K extends AppActionKind> = (typeof appActionFields)[K];
type FieldValue<F> = F extends { enum: readonly (infer V)[] } ? V : string;
export type AppAction = {
  [K in AppActionKind]: { id: string; kind: K } & {
    [P in keyof ActionFields<K>]: FieldValue<ActionFields<K>[P]>;
  };
}[AppActionKind];

export const appActionSchema = {
  anyOf: Object.entries(appActionFields).map(([kind, fields]) => ({
    type: "object",
    properties: { kind: choice([kind]), ...fields },
    required: ["kind", ...Object.keys(fields)],
    additionalProperties: false,
  })),
};

const idPattern =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const timePattern = /^(?:[01]\d|2[0-3]):[0-5]\d$/;

export function readAppAction(value: unknown): AppAction | undefined {
  if (typeof value !== "object" || value === null || Array.isArray(value))
    return;
  const input = value as Record<string, unknown>;
  const { kind, id } = input;
  if (typeof id !== "string" || !idPattern.test(id)) return;
  if (typeof kind !== "string" || !Object.hasOwn(appActionFields, kind)) return;
  const fields = appActionFields[kind as AppActionKind];
  if (Object.keys(input).length !== Object.keys(fields).length + 2) return;
  const parsed: Record<string, unknown> = { kind, id };
  for (const [key, field] of Object.entries(fields)) {
    const entry = input[key];
    if ("enum" in field) {
      if (!(field.enum as readonly unknown[]).includes(entry)) return;
      parsed[key] = entry;
    } else {
      if (typeof entry !== "string" || /[\u0000-\u001f\u007f]/.test(entry))
        return;
      const clean = entry.trim();
      if (
        key === "time" ? !timePattern.test(clean) : !clean || clean.length > 80
      )
        return;
      parsed[key] = clean;
    }
  }
  return parsed as AppAction;
}
