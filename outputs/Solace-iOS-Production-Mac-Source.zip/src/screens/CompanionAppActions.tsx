import React, { useEffect, useRef, useState } from "react";
import {
  Keyboard,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  readAppAction,
  type AppAction,
} from "../../server/src/companion-app-action";
import {
  habitCompletion,
  habitCompletionSummary,
  habitFromAction,
  matchingCompanionHabits,
  openCompanionDestination,
  reminderFromAction,
  repeatLabel,
} from "../companion-actions";
import { goalLabel, scheduleLabel } from "../habits-ui";
import { spacing } from "../layout";
import { reminderClockLabel } from "../reminder-time";
import { isMatchingReminder, saveReminder } from "../save-reminder";
import type { AppState } from "../store";
import { useTheme } from "../theme";
import { AppText, Button, Card } from "../ui";

type Prompt = {
  actionId?: string;
  title: string;
  description: string;
  error?: string;
  choices?: { label: string; confirm: () => Promise<string> }[];
};

function actionError(error: unknown) {
  return error instanceof Error
    ? error.message
    : "Solace couldn’t confirm the result. Please check and try again.";
}

function signedIn(app: AppState) {
  return (
    !!app.user?.id &&
    !!app.token &&
    !app.sessionExpired &&
    !app.appLocked &&
    !app.privacyCovered
  );
}

export function useCompanionActions(
  app: AppState,
  options?: {
    beforeNavigation?: () => void;
    verifyConfirmation?: (actionId: string) => Promise<void>;
  },
) {
  const { saveMode } = useTheme();
  const latestApp = useRef(app);
  latestApp.current = app;
  const active = useRef(false);
  const executing = useRef(false);
  const handled = useRef(new Set<string>());
  const [prompt, setPrompt] = useState<Prompt>();
  const [busy, setBusy] = useState(false);
  const pending = useRef<Prompt | undefined>(undefined);

  function show(next?: Prompt) {
    pending.current = next;
    setPrompt(next);
  }
  useEffect(() => {
    active.current = true;
    show();
    setBusy(executing.current);
    return () => {
      active.current = false;
      pending.current = undefined;
    };
  }, [app.user?.id]);

  function cancelPending(actionId?: string) {
    if (executing.current || !pending.current?.choices) return false;
    if (actionId && pending.current.actionId !== actionId) return false;
    show();
    return true;
  }

  async function execute(work: () => Promise<string>, proposed?: Prompt) {
    if (executing.current) return;
    const owner = latestApp.current.user?.id;
    if (!active.current || !signedIn(latestApp.current)) return;
    executing.current = true;
    if (proposed) setBusy(true);
    let verified = false;
    try {
      if (proposed?.actionId) {
        await options?.verifyConfirmation?.(proposed.actionId);
        if (pending.current !== proposed)
          throw new Error("This action is no longer pending.");
        verified = true;
      }
      const description = await work();
      if (active.current && latestApp.current.user?.id === owner)
        show({ title: "Solace action", description });
    } catch (error) {
      if (active.current && latestApp.current.user?.id === owner)
        show(
          verified && !options?.verifyConfirmation && proposed
            ? { ...proposed, error: actionError(error) }
            : {
                title: "Couldn’t complete the action",
                description: actionError(error),
              },
        );
    } finally {
      executing.current = false;
      if (proposed && active.current) setBusy(false);
    }
  }

  function receive(value: unknown, conversationId?: string) {
    const action = readAppAction(value);
    const current = latestApp.current;
    if (
      !action ||
      !active.current ||
      !signedIn(current) ||
      handled.current.has(action.id)
    )
      return;
    handled.current.add(action.id);
    if (action.kind === "cancel") {
      cancelPending();
      return;
    }
    if (executing.current) return;
    const owner = current.user!.id!;
    const authorized = () => {
      const account = latestApp.current;
      if (!active.current || !signedIn(account) || account.user?.id !== owner)
        throw new Error("Your session changed. Open Companion and try again.");
      return account;
    };

    switch (action.kind) {
      case "navigate":
      case "practice-start":
      case "progress":
      case "journal-search":
        Keyboard.dismiss();
        show();
        options?.beforeNavigation?.();
        openCompanionDestination(current, action, conversationId);
        break;
      case "theme":
        void execute(async () => {
          authorized();
          await saveMode(action.mode);
          return action.mode === "system"
            ? "Solace now follows your device appearance."
            : `Switched to ${action.mode} mode.`;
        });
        break;
      case "habit-progress": {
        const count = habitCompletionSummary(current.data, action.period);
        show({
          title: "Habit progress",
          description: `You recorded ${count} habit ${count === 1 ? "completion" : "completions"} this ${action.period}.`,
        });
        break;
      }
      case "habit-create":
        show({
          actionId: action.id,
          title: "Create habit?",
          description: `${action.name} · ${repeatLabel[action.schedule]} · Check off once per scheduled day`,
          choices: [
            {
              label: "Create habit",
              confirm: async () => {
                const result = await authorized().createHabit(
                  habitFromAction(action),
                  `companion-${action.id}`,
                );
                return `“${result.habit.name}” was saved to My Habits.`;
              },
            },
          ],
        });
        break;
      case "habit-complete": {
        const habits = matchingCompanionHabits(current.data, action.name);
        const now = new Date();
        const eligible = habits.flatMap((habit) => {
          try {
            return [
              {
                habit,
                occurrence: habitCompletion(current.data, habit.id, now),
              },
            ];
          } catch {
            return [];
          }
        });
        if (!eligible.length) {
          show({
            title: "No habit updated",
            description: habits.length
              ? "This habit isn’t available to log today."
              : "I couldn’t find an active habit with that exact name. Check My Habits and try again.",
          });
          break;
        }
        show({
          actionId: action.id,
          title: "Log habit completion?",
          description:
            eligible.length === 1
              ? `Mark “${eligible[0].habit.name}” complete for today (${goalLabel(eligible[0].occurrence.goal)})?`
              : "More than one active habit has that name. Choose which one to mark complete for today.",
          choices: eligible.map(({ habit, occurrence }, index) => ({
            label:
              eligible.length === 1
                ? "Mark complete"
                : `${index + 1}. ${habit.name} · ${scheduleLabel(habit.schedule)} · ${goalLabel(occurrence.goal)}`,
            confirm: async () => {
              const account = authorized();
              const latest = habitCompletion(account.data, habit.id);
              if (
                latest.write.day !== occurrence.write.day ||
                latest.write.amount !== occurrence.write.amount ||
                goalLabel(latest.goal) !== goalLabel(occurrence.goal)
              )
                throw new Error(
                  "The habit’s day or target changed. Ask again to review the new completion.",
                );
              if (latest.complete)
                return `“${latest.name}” is already complete for today.`;
              const saved = await account.setHabitProgress(
                habit.id,
                latest.write,
              );
              if (!saved.complete)
                throw new Error(
                  "Solace couldn’t confirm completion. Check the habit before trying again.",
                );
              return `“${latest.name}” was marked complete for today.`;
            },
          })),
        });
        break;
      }
      case "reminder-create": {
        const record = reminderFromAction(action);
        show({
          actionId: action.id,
          title: "Schedule reminder?",
          description: `${record.title} · ${reminderClockLabel(record)} · ${repeatLabel[action.repeat]} · Local time`,
          choices: [
            {
              label: "Save reminder",
              confirm: async () => {
                const account = authorized();
                if (
                  account.data.reminders.some((saved) =>
                    isMatchingReminder(saved, record),
                  )
                )
                  return "This reminder is already saved. Check Gentle Reminders for its delivery status.";
                const result = await saveReminder({
                  owner,
                  id: `companion-${action.id}`,
                  record,
                  save: (value) => account.save("reminders", value),
                });
                return result.message;
              },
            },
          ],
        });
        break;
      }
    }
  }

  function confirm(index: number) {
    // A new voice turn can replace a proposal while a button is pressed.
    const proposed = prompt;
    if (pending.current !== proposed) return;
    const choice = proposed?.choices?.[index];
    if (proposed?.actionId && choice) void execute(choice.confirm, proposed);
  }

  return {
    receive,
    cancelPending,
    prompt,
    busy,
    confirm,
    close: () => {
      if (!executing.current) show();
    },
  };
}

type ActionProps = { actions: ReturnType<typeof useCompanionActions> };

export function CompanionActionCard({ actions }: ActionProps) {
  const { colors } = useTheme();
  const { prompt, busy, confirm, close } = actions;
  if (!prompt) return null;
  return (
    <Card style={styles.content}>
      <AppText variant="heading" accessibilityRole="header">
        {prompt.title}
      </AppText>
      <AppText color={colors.muted} accessibilityLiveRegion="polite">
        {prompt.description}
      </AppText>
      {!!prompt.error && (
        <AppText color={colors.danger} accessibilityRole="alert">
          {prompt.error}
        </AppText>
      )}
      {prompt.choices?.map(({ label }, index) => (
        <Button
          key={index}
          title={busy ? "Saving…" : label}
          disabled={busy}
          onPress={() => confirm(index)}
        />
      ))}
      <Button
        title={prompt.choices ? "Cancel" : "Done"}
        variant="secondary"
        disabled={busy}
        onPress={close}
      />
    </Card>
  );
}

export function CompanionActionDialog({ actions }: ActionProps) {
  const { colors } = useTheme();
  if (!actions.prompt) return null;
  return (
    <Modal
      transparent
      visible
      animationType="none"
      onRequestClose={actions.close}
    >
      <SafeAreaView
        style={[styles.overlay, { backgroundColor: colors.overlay }]}
      >
        <Pressable
          style={StyleSheet.absoluteFill}
          accessible={false}
          onPress={actions.close}
        />
        <ScrollView style={styles.dialog} keyboardShouldPersistTaps="handled">
          <CompanionActionCard actions={actions} />
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, justifyContent: "center", padding: spacing.card },
  dialog: {
    width: "100%",
    maxWidth: 420,
    maxHeight: "85%",
    flexGrow: 0,
    alignSelf: "center",
  },
  content: { gap: spacing.row },
});
