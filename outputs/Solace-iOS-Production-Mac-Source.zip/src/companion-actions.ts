import type { AppAction } from "../server/src/companion-app-action";
import {
  addHabitDays,
  habitDay,
  habitInsights,
  habitRevisionOn,
  habitTarget,
  habitWeekStart,
  isHabitScheduled,
} from "../server/src/habit-contract";
import { getTimedPractice } from "../server/src/timed-practice-contract";
import { localDay } from "./content";
import type { ReminderInput } from "./notifications";
import { routes } from "./routes";
import type { AppState } from "./store";

type Destination = Extract<AppAction, { kind: "navigate" }>["destination"];
type Shortcut = readonly [
  name: string,
  root?: string,
  params?: Record<string, unknown>,
];

const shortcuts: Record<Destination, Shortcut> = {
  today: [routes.today],
  "daily-pause": [routes.today, undefined, { section: "daily-pause" }],
  solace: [routes.solace],
  companion: [routes.companion],
  "conversation-history": [routes.history],
  journal: [routes.journal],
  "journal-editor": [routes.journalEditor],
  explore: [routes.explore],
  "wellness-tools": [routes.wellnessTools, routes.explore],
  "ambient-mixer": ["ambient-mixer", routes.explore],
  "wellness-toolkit": ["toolkit", routes.explore],
  "guided-techniques": [routes.techniques, routes.explore],
  "guided-programs": [routes.guidedPrograms, routes.explore],
  "wellness-plan": [routes.wellnessPlan, routes.explore],
  "timed-practice": [routes.timedPractice, routes.explore],
  habits: [routes.habits, routes.explore],
  "habit-library": [routes.habitLibrary, routes.explore],
  "habit-insights": [routes.habitInsights, routes.explore],
  "habit-garden": [routes.habitGarden, routes.explore],
  journey: [routes.journey],
  "journey-activity": ["journey-activity", routes.journey],
  milestones: ["journey-milestones", routes.journey],
  "personal-goal": ["journey-goal", routes.journey],
  profile: [routes.profile],
  appearance: ["settings", routes.profile],
  reminders: ["reminders", routes.profile],
  memory: [routes.memory, routes.profile],
  support: [routes.support, routes.profile],
  account: ["account", routes.profile],
  privacy: ["account", routes.profile, { section: "privacy" }],
  about: ["about", routes.profile],
  checkin: ["checkin", routes.today],
  moments: ["moments", routes.explore],
  resources: ["resources", routes.explore],
  "sleep-guide": ["sleep", routes.explore],
  grounding: ["grounding", routes.explore],
  affirmations: ["affirmation", routes.explore],
  "saved-affirmations": ["saved-affirmations", routes.journey],
  "daily-challenge": ["challenge", routes.explore],
  "reflective-checkins": ["assessments", routes.explore],
};

const practiceFocus = {
  breathing: "calm",
  grounding: "focus",
  "wind-down": "sleep",
} as const;

export type NavigationAction = Extract<
  AppAction,
  { kind: "navigate" | "practice-start" | "progress" | "journal-search" }
>;

export function openCompanionDestination(
  app: Pick<AppState, "navigate" | "switchSolaceMode">,
  action: NavigationAction,
  conversationId?: string,
  now = new Date(),
) {
  if (action.kind === "navigate") {
    const [name, root, params] = shortcuts[action.destination];
    if (name === routes.companion || name === routes.history) {
      if (conversationId)
        app.navigate(routes.companion, { id: conversationId });
      else app.switchSolaceMode("companion");
      if (name === routes.history) app.navigate(routes.history);
      return;
    }
    if (root) app.navigate(root);
    app.navigate(name, params);
    return;
  }
  if (action.kind === "progress") {
    app.navigate(routes.journey, { period: action.period });
    return;
  }
  if (action.kind === "journal-search") {
    const today = localDay(now);
    app.navigate(routes.journal, {
      entryDay: action.when === "today" ? today : addHabitDays(today, -1),
    });
    return;
  }
  app.navigate(routes.explore);
  app.navigate(routes.momentPlayer, {
    activity: getTimedPractice(practiceFocus[action.practice], action.minutes),
    source: "chat",
    provider: "offline",
  });
}

type Recurrence = Extract<AppAction, { kind: "reminder-create" }>["repeat"];
export const repeatLabel: Record<Recurrence, string> = {
  daily: "Every day",
  weekdays: "Weekdays",
  weekends: "Weekends",
};
const repeatDays: Record<Recurrence, number[]> = {
  daily: [0, 1, 2, 3, 4, 5, 6],
  weekdays: [1, 2, 3, 4, 5],
  weekends: [0, 6],
};

export function reminderFromAction(
  action: Extract<AppAction, { kind: "reminder-create" }>,
): ReminderInput {
  const [hour, minute] = action.time.split(":").map(Number);
  return {
    type: "custom",
    title: action.title,
    hour,
    minute,
    days: repeatDays[action.repeat],
    enabled: true,
  };
}

export function habitFromAction(
  action: Extract<AppAction, { kind: "habit-create" }>,
): Parameters<AppState["createHabit"]>[0] {
  return {
    name: action.name,
    category: "self-care",
    color: "lavender",
    icon: "leaf",
    goal: { type: "completion" },
    schedule:
      action.schedule === "daily"
        ? { type: "daily" }
        : { type: "weekdays", days: repeatDays[action.schedule] },
    reminderTime: null,
  };
}

type HabitData = Pick<AppState["data"], "habits" | "habitProgress">;

export function matchingCompanionHabits(data: HabitData, name: string) {
  const normalize = (value: string) =>
    value.normalize("NFKC").trim().toLocaleLowerCase().replace(/\s+/g, " ");
  const needle = normalize(name);
  return data.habits.filter(
    (habit) => habit.status === "active" && normalize(habit.name) === needle,
  );
}

export function habitCompletion(data: HabitData, id: string, now = new Date()) {
  const habit = data.habits.find(
    (item) => item.id === id && item.status === "active",
  );
  if (!habit)
    throw new Error(
      "This habit is no longer available. Your progress is unchanged.",
    );
  const day = habitDay(habit.timeZone, now);
  const revision = habitRevisionOn(habit, day);
  if (!revision || !isHabitScheduled(habit, day))
    throw new Error(
      "This habit can’t be logged today. Your progress is unchanged.",
    );
  const progress = data.habitProgress.find(
    (record) => record.habitId === id && record.day === day,
  );
  return {
    name: habit.name,
    goal: revision.goal,
    complete: progress?.complete === true,
    write: {
      day,
      amount: habitTarget(revision.goal),
      expectedRevision: progress?.revision ?? 0,
    },
  };
}

export function habitCompletionSummary(
  data: HabitData,
  period: "week" | "month",
  now = new Date(),
) {
  const today = localDay(now);
  const start =
    period === "week" ? habitWeekStart(today) : `${today.slice(0, 7)}-01`;
  return habitInsights(
    data.habits,
    data.habitProgress,
    start,
    today,
    today,
    now,
  ).completedActions;
}
