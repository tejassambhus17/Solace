# Solace AI

A personal wellness companion built with React Native + Expo, a Node.js API and persistent SQLite storage. Solace connects a check-in, a conversation, a useful Moment and a gentle reflection, with personalization that the user controls.

## Current implementation

The source now includes the master-brief feature set: an expressive petal companion, structured Solace Moments, three ambient environments, consent-based memory, a calendar Journey, weekly reflections, personal goals, optional streaks and live Voice Talk. The five tabs are **Today → Solace → Explore → Journey → Profile**. Explore includes Solace Moments, breathing, grounding, reflections, the saved toolkit, guides, reflective check-ins, plans, affirmations and challenges. Moments is also available from Today and the Solace header.

The premium expansion adds direct chat-to-Moment recommendations, a customizable Daily Pause, weekly stories, a four-track sound mixer and earned milestone celebrations. See the [feature checklist and QA evidence](docs/PREMIUM_EXPANSION.md), [requirements](docs/REQUIREMENTS.md) and [verification record](docs/VERIFICATION.md).

Companion shows the current practice suggestion with its duration, technique artwork and a short reason. Start practice opens the existing player, Not now dismisses that suggestion, and the info button opens the full explanation.

The Companion overflow opens New Conversation and Conversation History. The latest eligible reply has a playback button beside its message details.

Companion can also act on explicit requests in text or Live Voice. It can open supported screens, show recorded habit counts, switch appearance, and prepare habit changes and recurring reminders for review. Journal date requests open a filtered Journal on the device. [Supported actions and verification](docs/VERIFICATION.md#companion-actions-and-six-issue-fixes)

**OpenAI is the only live AI provider.** The Node API serves Companion, personalized Moments, Journal reflections, habit suggestions, plan previews, weekly prompts, transcription, and spoken replies. Offline mode labels built-in guidance and curated activities. Typing remains available when voice is unavailable.

## The daily experience

For the nested screens, see the [route and design audit](docs/SOLACE_SCREEN_DESIGN_AUDIT.md) and [screen-by-screen verification report](docs/SOLACE_DESIGN_CONSISTENCY_REPORT.md).

Today opens with a scenic greeting, actual check-in and Moment counts, and the latest recorded mood. Tap a watercolor petal to open the check-in, or start the five-minute Calm Reset. Today’s Progress combines applicable Daily Pause steps and scheduled habit occurrences from saved activity. View Details opens Journey. Daily Pause tracks check-in, Moment and reflection from saved activity and opens the next step. You can replace a suggestion, choose its length, skip it for the day or turn Daily Pause off. Illustrated Quick Actions open breathing, reflection, sleep, and grounding.

After a mood check-in, try a short reset in the existing practice player or review a draft for Companion. The draft starts with the mood, and the note is optional. You can edit the draft before sending it. Completed resets use the same Journey history and optional feedback as other practices.

The loved light theme remains blush-ivory and forest. Dark mode uses a black canvas, neutral graphite, warm ivory text, champagne actions and restrained lilac/peach/sage accents. Welcome, login, signup and Today have no upper-right profile shortcut. Typography and artwork follow [the existing design system](DESIGN.md), including [matched daily-pause artwork](assets/DAILY_PAUSE_ARTWORK.md).

The floating navigation respects safe-area and keyboard clearance. Each tab keeps its navigation stack while you switch. A circular spotlight follows the active tab and moves immediately when Reduce Motion is enabled. Supported iOS uses guarded native Liquid Glass, with blur and Reduce Transparency fallbacks. Android uses an opaque tonal surface.

All five tab roots share the Today lotus and wordmark, with the same safe-area spacing and room for header actions. The launcher icons use Solace’s original three-petal artwork. iOS chooses the default, dark, or tinted icon from its Home Screen appearance settings. Android applies its launcher mask and uses the monochrome layer when themed icons are enabled on a supported launcher. Install a new native build to see these icon assets. [Four-tab polish and verification](docs/VERIFICATION.md#four-tab-design-and-usability-sweep) · [Icon rebuild steps](docs/VERIFICATION.md#brand-headers-and-native-app-icons)

The [performance report](docs/PERFORMANCE_OPTIMIZATION_REPORT.md) records emulator diagnostics, long-list and player regressions, and release checks. Use the [physical-device checklist](docs/PHYSICAL_DEVICE_QA_CHECKLIST.md) to verify frame pacing, keyboard behavior and native audio on Android and iPhone.

Tap a different tab or drag inside the bottom bar to switch and pick up where you left off. Tap the selected tab to return to its home, including the Companion and My Journal chooser for Solace. Today’s **See All** opens the full Explore library with filters and search cleared. Journal drafts stay available. Guarded forms ask before discarding unsaved changes when you go back or reset the active tab. [Gesture behavior and verification](docs/NAVIGATION_GESTURES_QA.md)

First launch offers a five-page tour, followed by sign-in and an optional personalization choice. Open About Solace to replay the introduction. [Onboarding behavior and verification](docs/ONBOARDING_QA.md)

Open **Explore → Healthy Habit Builder** to find Today, My Habits, Insights and Garden in one hub. Create and manage habits, log actual progress and see earned garden growth. Today, Journey, Companion and Profile link into the same records and controls. Journey’s Habit Progress card opens Insights with the selected date range when available. [Solace Habits and verification](docs/HABITS_QA.md)

## Solace Moments and the companion

The Solace tab opens with Companion and My Journal choices and remembers the last used mode for each account. Companion supports text, conversation history, live Voice Talk and recorded messages. My Journal supports drafts, saved entries, mood, tags, bookmarks and search. AI reflection and Companion handoff require selecting an excerpt and approving the provider disclosure. In Explore, Your wellness tools opens Guided Techniques and Healthy Habit Builder. Guided Techniques uses the same Moment player and Journey completion records. The navigation map, privacy behavior and device acceptance steps are in the [Companion, Journal and Guided Techniques QA report](docs/COMPANION_JOURNAL_TECHNIQUES.md).

Companion keeps New conversation and Conversation history in its menu and retains drafts for retry. Ending Live Voice returns to Companion while call cleanup and history refresh finish. Journal distinguishes a protected device draft, a pending sync and a confirmed account save, and accepts up to 30 unique tags of 80 characters each. Completed classic breathing and grounding practices save to Journey before optional feedback. Guided Techniques shows its pacing before starting and confirms the actual recorded duration after saving. Journey’s Latest activity shows the most recent eligible record in the selected period and opens its existing detail. Protected Journal titles stay private and device-only records show their sync status.

The Journal editor offers a tall purple writing surface, a plain-text bullet tool, a live word count, an optional scrollable mood row and editable tag chips. The date button opens a calendar with dots for saved entries. Select a date to open its entries or start a dated draft when no different-date draft is already in progress. Reflect with Solace can offer an excerpt picker after the entry has synced. Sharing still requires approving the selected excerpt.

Describe how you feel, review the suggested Moment and choose **Forest Sanctuary**, **Ocean Calm** or **Twilight Sky**. The generator returns bounded, schema-validated activity data: type, duration, steps, optional breathing rhythm and reflection prompts. It cannot send executable UI instructions. A configured provider uses structured output; the built-in alternative is explicitly curated. Urgent distress takes the human-support route instead of offering a generated activity.

Guided Techniques breathing practices use an immersive player with centered guidance and an environment sheet. The transport and environment control fit one viewport at standard phone sizes. Short windows and larger system text can scroll when the content needs more space. The practice timer, audio controls, and Journey save flow are shared with Moments. [Player verification](docs/VERIFICATION.md#guided-techniques-breathing-player)

The Make a Moment action in Chat carries the chosen feeling and conversation link into the activity, with an optional return to that conversation afterward. The immersive player has an active-time clock, guidance, progress, pause/resume, exit confirmation, background pause, environment switching and optional bundled ambient sound. Original synthesized sound loops are packaged locally. Playback status and failures are visible. Completion and helpfulness are saved to the authenticated account, with retry behavior that retains the result rather than claiming an unsuccessful save worked.

The recognizable petal companion has idle, listening, thinking, speaking, celebration and breathing states. Recording, requests, playback, practice timing and earned milestones drive these states. Reduced-motion settings are respected. No expression diagnoses the user's feelings.

## Conversation and voice

New chat opens with a woodland lotus scene, contextual quick replies, and a Guided Breath card. After the first send, the conversation uses a compact companion header. Saved conversations open in that layout with recorded timestamps and reply sources. The overflow starts with **New Conversation** and keeps history, practices, support and reply playback available. Urgent replies provide a direct human support action. Unsent text stays in account-scoped memory across navigation and recoverable errors.

Explore opens with a twilight lake, compact category filters including Sleep, search, and a shortcut to the saved toolkit. Categories and search results use illustrated cards that open matching practices and tools. Recommendations include a three-minute Breath Reset, five-minute Five Senses grounding, Quick Reflection with a four-minute estimate for the self-paced journal, and a ten-minute Sleep Wind Down. The cards form a two-column grid where there is room and stack on narrow layouts or at larger system text sizes. Create Your Wellness Plan builds an editable three-day routine from a goal, preferred activity types, and a daily time commitment. Guided Programs in Explore More opens ready-made sequences for sleep, stress relief, mindful mornings, and focus. Both use saved practices to show day-by-day progress in Journey, where each plan can be reopened. Explore More also links to Wellness Toolkit and Reflective Check-ins. Two cards at the bottom open Wellness Tools and Build a Timed Practice. The tools library gives direct access to grouped experiences and offers Relax, Move, and Grow filters. Timed Practice previews a 5-, 10-, 15-, or 20-minute session for Calm, Focus, Sleep, or Energy. It uses the existing Moment player and saves completed active time to Journey. The API and app should be released together so the server can validate the longer registered sessions.

The floating composer puts transcription, the message field, Send and Live Voice in that order. The recording microphone adds the recognized text to the editable draft, which you can review before tapping Send. The waveform button opens the full-screen Voice Companion. Its status follows the session, its timer starts when WebRTC connects, and its meter and lotus lighting share available input and output levels. When a level is unavailable, the lighting follows the session phase. Reduce Motion shows the original still scene.

OpenAI Realtime receives microphone audio and returns spoken replies over WebRTC. Speak to interrupt, mute the microphone, or end the session. On supported native builds the Speaker button changes the built-in output preference, while the system manages connected headphones. Solace saves available transcripts in the active conversation, including user turns whose spoken replies were interrupted. Explicit crisis signals stop live voice and show the existing human-support guidance. Back and End return to the same conversation and retain unsent text. After a connection failure, Continue in Chat returns to Companion and Retry becomes available once local cleanup finishes.

Today points first-time users to the mood check-in. After saving, users can start or dismiss one suggested practice. A saved practice shows its active time and offers a skippable mood check-in. Journey shows the recorded response and timestamp on the practice detail when it can link the two records.

Voice Talk uses the backend's existing `OPENAI_API_KEY` and defaults to `OPENAI_REALTIME_MODEL=gpt-realtime-2.1-mini` and `OPENAI_REALTIME_VOICE=marin`. Set `OPENAI_REALTIME_MODEL=gpt-realtime-2.1` only if that model is accessible to the OpenAI project. `OPENAI_REALTIME_ENABLED=false` disables live voice independently of text. The server negotiates audio-only WebRTC and uses a private sideband connection to authorize each spoken reply and save transcripts. Solace does not store raw live microphone audio.

`REALTIME_SESSION_SECONDS` defaults to 300, `REALTIME_DAILY_SECONDS` to 900 per account and `REALTIME_GLOBAL_DAILY_SECONDS` to 3600 across the API. Daily accounting uses UTC. The server reserves time before connecting, admits one session per account, and sends an explicit hangup when a session ends, expires or loses its heartbeat. Limits control session time. Actual provider charges depend on audio and token usage.

Install dependencies with `npm run setup`. Build and install a new Android binary with `node scripts/runtime.cjs expo run:android`, build for iOS on a Mac with `npm run ios`, or use the existing EAS profiles. For an existing generated native project, apply its configuration first with `node scripts/runtime.cjs expo prebuild --platform android --no-install --no-clean` or the same command with `--platform ios` on a Mac. Keep the existing iOS signing selection. Live Voice Talk uses the native WebRTC module, which requires a new build. Web Voice Talk needs HTTPS or localhost and browser microphone access. See [Realtime Voice verification](docs/VERIFICATION.md#realtime-voice-companion) for build and device checks.

## Memory you can explain and change

**Profile → What Solace remembers** shows saved preferences, categories, approval state and available source links. Users can add, correct, approve, remove or explicitly clear preferences, or turn personalization off. Activity completion may offer editable wording, but saving always requires an explicit action. Solace does not silently create memories.

Recommendations name the approved memory used when it influences a suggestion. Turning personalization off excludes saved preferences from new personalized suggestions. Editing/removing a memory, deleting a source that supplied one, or revoking personalization resets the older context used for future AI replies. Existing conversation text remains visible and exportable; it is not silently rewritten. Deleting a conversation or source session also removes its derived memories. Pending responses built from invalidated context are rejected rather than committed.

## Journey, goals and gentle milestones

Journey opens with a weekly view and remembers each account's Week, Month or All time preference on this device. Its calendar opens day-by-day history, and the summaries count distinct check-in days, completed Moments and actual active time. Prior-period comparisons appear when the previous period has activity. The saved story opens reflections, affirmations and check-ins.

Choose a calendar week to write a reflection or request an editable draft based on your saved activity and feedback. The local recorded summary is labeled when live AI is off. A configured provider receives counts to suggest a question. When there is no activity to summarize, Journey offers a guided prompt. Weekly reflections are only saved when you choose to save, and you can reopen, edit or delete them.

Set a goal for check-in days, completed Moments, mindful minutes or saved reflections, over a week, month or all time. Goals can be edited, paused, resumed or removed. Milestones such as the first check-in, three- and seven-day streaks, and first weekly reflection derive from saved records. Unsynced writing is marked as waiting to sync and does not count toward account milestones.

## Existing foundations retained

- Accounts: signup/login/logout, secure session handling, persisted history and server-enforced account isolation.
- Practices: timed breathing, optional five-senses grounding, journaling, three reflective assessments, five guidance categories, editable plans, affirmations and small challenges.
- Toolkit: private saved practices and resources, idempotent saves, export and deletion.
- Profile photos: system picker, client preparation and independent server JPEG normalization to 256px, input limits and metadata removal; photos remain private to the account.
- Reminders: private local notification schedules and destination routing. Browser preferences do not pretend to schedule native notifications.
- Data controls: approved memory, export, logout, account deletion, unsynced-writing retry/discard and theme preferences.

Profile shows the signed-in name and photo against mountain artwork for the active theme. **Edit Profile** opens name and photo controls. **Personalize Solace** groups reminders, saved memories, and appearance preferences. Reminder status accounts for device permission and local scheduling. **Appearance & preferences** groups theme, sound and accessibility guidance, Biometric Lock, and the approved-preferences switch. **Privacy & Support** links to JSON file export, account deletion, human support, and About Solace. About explains Solace’s role and how the app handles conversations.

Native check-in/journal drafts use bounded account-scoped SecureStore. Up to ten submitted check-ins/reflections can wait for retry after recoverable connection errors. Draft writes debounce 650ms and attempt protection when leaving the app; abrupt termination before a successful write can lose recent edits. Web writing is memory-only for the open tab. Cold launch still needs online API session restoration; chat and complete account snapshots are not placed in the protected writing vault.

An unchanged chat draft reuses its request ID after a connection failure during the current app session. The API can replay its saved turn for up to 24 hours, including across API restarts. Editing the draft starts a new request. Chat drafts and pending request IDs live in app memory.

## Local setup

The app and server have separate lockfiles. Root-only `npm ci` does not install the server's tsx dependency. The tested runtime is Node 24 LTS; the runtime wrapper validates compatible versions and never silently runs Expo on Windows' default Node 20. See [Mac/simulator repair instructions](docs/LOCAL_DEVELOPMENT.md).

```powershell
npm run setup
npm run doctor
npm run dev
```

Setup installs both lockfiles with development/platform packages, compiles the API and creates only missing environment files. Existing environment files and database records are preserved. The dev supervisor verifies its own API child before starting Expo. Private server configuration and relative database paths are anchored to `server/`; a busy-port failure cannot rewrite the running API's database.

The API normally uses port 3001 and Expo web uses 8081. Separate terminals can run `npm run server` and `npm run web`. A packaged local preview uses `npm run export:web:preview`, then `npm run preview` on port 8082. Stop the owned development processes with Ctrl+C.

Only public connection configuration belongs in the root environment. Development defaults use iOS simulator `127.0.0.1:3001`, Android emulator `10.0.2.2:3001` and the web hostname on port 3001. A physical phone needs a reachable LAN or hosted address. An Android debug build can also use an explicit loopback address over USB reverse. Release clients require an explicit HTTPS API and reject loopback, private network addresses and local-only hostnames. Reload Expo after public configuration changes and rebuild installed release binaries.

Google sign-in on Android and iOS uses a system browser and the existing Solace session. To link an existing account, sign in first and open **Profile → Edit Profile → Google sign-in**. Google Cloud settings, the HTTPS callback, optional SMTP recovery and native rebuild steps are in the [authentication setup guide](docs/GOOGLE_AUTH_SETUP.md).

Use **Profile → Appearance & preferences → Biometric Lock** to protect an existing session, My Journal or both on an enrolled device. Solace can lock immediately or after one or five minutes in the background. When the app lock is required, Solace covers your content and opens the device biometric prompt automatically. It checks the saved server session before opening your previous screen. If the prompt is cancelled or the session check fails, retry when available or recover through normal sign-in. The web preview keeps the email/password session for the current browser tab.

Set `OPENAI_API_KEY` in **server/.env** or the private server environment. Restart the API after changing configuration. `AI_MODE=live` requires an OpenAI key, `auto` selects live with a key, and `offline` uses labeled built-in guidance. See the [OpenAI migration and setup guide](docs/OPENAI_MIGRATION.md).

## Project map

```text
App.tsx                    app shell and four-tab navigation
src/Navigation.tsx         platform-aware floating navigation
src/screens/Discover.tsx   Today and the daily pause
src/screens/Moments.tsx    generation, library and immersive player
src/Companion.tsx          event-driven petal character
src/Environment.tsx        forest, ocean and twilight visual environments
src/moments.ts             activity guards and active-time player helpers
src/screens/Journey.tsx    calendar, summaries, goals and milestones
src/progress.ts            recorded participation and calendar helpers
src/VoiceControls.tsx      recording, transcript review and reply playback
src/voice-session.ts       cancellable account/conversation-scoped voice turn
src/screens/Core.tsx       welcome, accounts, chat and history
src/screens/Wellness.tsx   original activities, resources and reflections
src/screens/ProfileHome.tsx  grouped profile overview and account badges
src/screens/Profile.tsx      account, memory, reminders, privacy and About Solace
src/store.tsx              authenticated state, API and protected sessions
src/offline.ts             bounded protected-writing vault
src/notifications.ts       native local reminders and tap routing
server/src/                auth, persistence, AI, Moments, weekly and voice API
assets/                    original/botanical illustrations and ambient loops
docs/                      requirements, verification and release guides
```

## Checks and release work

```powershell
npm run typecheck
npm run server:typecheck
npm run server:test
npm run test:tooling
npm run test:api-config
npm run test:session-state
npm run test:google-auth
npm run test:moments
npm run test:progress
npm run test:voice
npm run test:native-config
npm run test:routine
npm run test:offline
npm run test:insights
npm run test:wellness
npm run test:reminders
npm run server:build
npm run export:web:preview
npm run export:android
npm run export:ios
```

The November 6 stabilization pass includes an integrated two-account browser journey, matched defect retests, and checks on a USB-connected Android 15 handset. The report lists the exact scenarios, commands and outstanding release gates. [QA stabilization report](docs/QA_STABILIZATION.md) · [Verification record](docs/VERIFICATION.md)

The physical Android debug build passed signup, session restoration, mood saving, built-in chat and history checks using the local API over USB. The device pass also verified the chat keyboard fix. [Device verification](docs/VERIFICATION.md#physical-android-smoke-test--6-november-2026)

The overnight candidate adds recovery checks for delayed account snapshots, hidden practices and interrupted Live Voice. The API keeps its health probe independent of the client quota and uses a bounded shutdown. See the [overnight engineering report](docs/SOLACE_OVERNIGHT_ENGINEERING_REPORT.md) for test evidence and the remaining release checks.

On a phone, open Profile → Appearance & Preferences → Test haptic feedback to try the same confirmation effect used for saved practices. The device’s system haptics setting applies.

Today includes a five-minute Calm Reset, the recorded daily routine progress, and direct Explore More links to Guided Programs, Wellness Toolkit and Check-Ins. The full Explore library is available from See All and the bottom compass.

Submission still needs public HTTPS with a persistent database and production provider configuration, a rebuilt functional APK tested on a physical phone, iOS verification, native reminder tests and a demo recorded from the final build. The user's deadline is Tuesday, 10 November 2026 at 11:59 AM IST. See [release instructions](docs/RELEASE.md).

SQL.js currently supports one API instance with a private persistent disk. Use HTTPS, restricted origins/proxy settings and backups in deployment. SQLite is not application-encrypted. Large-account pagination and native performance profiling remain scaling work. Solace is an AI wellness companion, not a licensed therapist, diagnostic tool or emergency service. It makes no clinical, HIPAA or certification claim. Social feeds, public profiles, following, community messages, therapist booking, OAuth, email password reset and remote push infrastructure are outside the implemented scope.
