# Solace production iPhone build
Extract the archive on the Mac and open Terminal in the extracted folder. Run bash scripts/build-ios-azure.sh with Xcode, an existing signing team and the iPhone connected. Select the iPhone and signing team if Xcode requests them. See docs/RELEASE.md for device requirements.
