import React, {
  useEffect,
  useRef,
  useState,
  type KeyboardEvent,
  type ReactNode,
} from "react";
import {
  ActivityIndicator,
  Animated,
  Easing,
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
  useWindowDimensions,
  type ImageSourcePropType,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import type { WellnessGoal } from "../../server/src/wellness-goals";
import { useReducedMotion } from "../Companion";
import { playHaptic } from "../haptics";
import { useGuardedBack, useTabResetGuard } from "../navigation-reset";
import { artGradient, useTheme } from "../theme";
import { AppText, Icon, LotusMark } from "../ui";

type GoalOption = {
  id: WellnessGoal;
  title: string;
  description: string;
  light: ImageSourcePropType;
  dark?: ImageSourcePropType;
};

const exploreGoal: GoalOption = {
  id: "explore",
  title: "Just explore",
  description: "Discover everything Solace offers at your own pace.",
  light: require("../../assets/today-quick-breathe.jpg"),
};

const goals: readonly GoalOption[] = [
  {
    id: "calm",
    title: "Feel calmer",
    description: "Find a little room to breathe and feel grounded.",
    light: require("../../assets/voice-companion-dawn.jpg"),
    dark: require("../../assets/voice-companion-night.jpg"),
  },
  {
    id: "sleep",
    title: "Sleep better",
    description: "Unwind, rest deeply, and wake up refreshed.",
    light: require("../../assets/goals-sleep.jpg"),
  },
  {
    id: "feelings",
    title: "Understand my feelings",
    description: "Explore your emotions, patterns, and what you need.",
    light: require("../../assets/goals-feelings.jpg"),
  },
  {
    id: "habits",
    title: "Build healthy habits",
    description: "Grow through small, consistent steps.",
    light: require("../../assets/redesign-explore-breathe.jpg"),
  },
  {
    id: "focus",
    title: "Improve my focus",
    description: "Find clarity and stay present in daily life.",
    light: require("../../assets/today-quick-focus.jpg"),
  },
  exploreGoal,
];

function selectedIds(selection: ReadonlySet<WellnessGoal>) {
  return goals.filter(({ id }) => selection.has(id)).map(({ id }) => id);
}

const backgrounds = {
  light: require("../../assets/goals-dawn.jpg"),
  dark: require("../../assets/goals-twilight.jpg"),
};

const goalPalette = {
  light: {
    canvas: "#F9EBF3",
    text: "#2B2038",
    muted: "#55455F",
    card: "#FFF8FC",
    border: "#E5CDD9",
    selected: "#F7E6F5",
    selection: "#A267B3",
    checkBorder: "#987E9C",
    check: "#653A80",
    checkInk: "#FFFFFF",
    actionStart: "#75437F",
    actionEnd: "#472A5E",
  },
  dark: {
    canvas: "#160F22",
    text: "#F8EEF9",
    muted: "#D6C4DD",
    card: "#271C31F0",
    border: "#56415F",
    selected: "#372544F5",
    selection: "#BB8CCC",
    checkBorder: "#A288B0",
    check: "#D8B4F0",
    checkInk: "#241632",
    actionStart: "#784C91",
    actionEnd: "#51346E",
  },
};

function goalImage(goal: GoalOption, dark: boolean) {
  return dark ? (goal.dark ?? goal.light) : goal.light;
}

function GoalCanvas({
  children,
  welcome,
  screenId,
}: {
  children: ReactNode;
  welcome?: boolean;
  screenId: string;
}) {
  const { resolved } = useTheme();
  const { width } = useWindowDimensions();
  const palette = goalPalette[resolved];
  return (
    <View style={[styles.canvas, { backgroundColor: palette.canvas }]}>
      <StatusBar style={resolved === "dark" ? "light" : "dark"} />
      <Image
        source={backgrounds[resolved]}
        accessible={false}
        accessibilityIgnoresInvertColors
        fadeDuration={0}
        resizeMode="cover"
        style={styles.imageFill}
      />
      <SafeAreaView style={styles.canvas}>
        <ScrollView
          testID={screenId}
          contentInsetAdjustmentBehavior="never"
          showsVerticalScrollIndicator={false}
          style={styles.canvas}
          contentContainerStyle={[
            styles.scroll,
            welcome && styles.welcomeScroll,
            { paddingHorizontal: width < 360 ? 13 : 20 },
          ]}
        >
          <View style={styles.column}>{children}</View>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

function GoalBrand() {
  const { resolved } = useTheme();
  return (
    <View style={styles.brand}>
      <LotusMark size={52} />
      <AppText
        variant="heading"
        color={goalPalette[resolved].text}
        style={styles.wordmark}
      >
        Solace
      </AppText>
    </View>
  );
}

function GoalIntro({ title, children }: { title: string; children: string }) {
  const { resolved } = useTheme();
  const palette = goalPalette[resolved];
  return (
    <View style={styles.intro}>
      <AppText
        accessibilityRole="header"
        variant="title"
        color={palette.text}
        style={styles.title}
      >
        {title}
      </AppText>
      <View style={styles.introDescription}>
        {resolved === "dark" && (
          <View
            pointerEvents="none"
            style={[
              styles.captionVeil,
              artGradient(
                "linear-gradient(180deg, #170C2300 0%, #170C237A 26%, #170C237A 74%, #170C2300 100%)",
              ),
            ]}
          />
        )}
        <AppText color={palette.text} style={styles.introCopy}>
          {children}
        </AppText>
      </View>
    </View>
  );
}

function GoalCard({
  goal,
  checked,
  disabled,
  reduceMotion,
  artWidth,
  onPress,
}: {
  goal: GoalOption;
  checked: boolean;
  disabled: boolean;
  reduceMotion: boolean;
  artWidth: number;
  onPress: () => void;
}) {
  const { resolved } = useTheme();
  const palette = goalPalette[resolved];
  const [focus, setFocus] = useState(false);
  const [selection] = useState(() => new Animated.Value(checked ? 1 : 0));
  const surface = checked ? palette.selected : palette.card;
  useEffect(() => {
    if (reduceMotion) {
      selection.setValue(checked ? 1 : 0);
      return;
    }
    const animation = Animated.timing(selection, {
      toValue: checked ? 1 : 0,
      duration: 160,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: Platform.OS !== "web",
      isInteraction: false,
    });
    animation.start();
    return () => animation.stop();
  }, [checked, reduceMotion, selection]);

  return (
    <Pressable
      testID={`wellness-goal-${goal.id}`}
      accessibilityRole="checkbox"
      accessibilityLabel={goal.title}
      accessibilityHint={goal.description}
      accessibilityState={{ checked, disabled }}
      aria-checked={checked}
      disabled={disabled}
      onPress={onPress}
      onKeyDown={
        Platform.OS === "web"
          ? (nativeEvent) => {
              // RN Web only maps Space to Pressable's onPress for button roles.
              const event =
                nativeEvent as unknown as KeyboardEvent<HTMLElement>;
              if (
                event.key !== " " ||
                event.altKey ||
                event.ctrlKey ||
                event.metaKey ||
                event.shiftKey
              )
                return;
              event.preventDefault();
              if (!event.repeat && !disabled) onPress();
            }
          : undefined
      }
      onFocus={() => setFocus(true)}
      onBlur={() => setFocus(false)}
      style={({ pressed }) => [
        styles.goalCard,
        {
          backgroundColor: surface,
          borderColor: focus
            ? palette.check
            : checked
              ? palette.selection
              : palette.border,
          opacity: pressed ? 0.83 : 1,
          paddingStart: artWidth + 7,
        },
      ]}
    >
      <View pointerEvents="none" style={[styles.goalArt, { width: artWidth }]}>
        <Image
          source={goalImage(goal, resolved === "dark")}
          accessible={false}
          accessibilityIgnoresInvertColors
          fadeDuration={0}
          resizeMode="cover"
          resizeMethod="resize"
          style={styles.imageFill}
        />
        <View
          style={[
            StyleSheet.absoluteFill,
            artGradient(
              `linear-gradient(90deg, transparent 67%, ${surface} 100%)`,
            ),
          ]}
        />
      </View>
      <View style={styles.goalCopy}>
        <AppText
          variant="heading"
          color={palette.text}
          style={styles.goalTitle}
        >
          {goal.title}
        </AppText>
        <AppText
          variant="caption"
          color={palette.muted}
          style={styles.goalDescription}
        >
          {goal.description}
        </AppText>
      </View>
      <View
        accessible={false}
        importantForAccessibility="no-hide-descendants"
        style={[
          styles.checkbox,
          { borderColor: checked ? palette.check : palette.checkBorder },
        ]}
      >
        <Animated.View
          style={[
            styles.checkboxMark,
            {
              backgroundColor: palette.check,
              opacity: selection,
              transform: [
                {
                  scale: selection.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.72, 1],
                  }),
                },
              ],
            },
          ]}
        >
          <Icon name="checkmark" color={palette.checkInk} size={17} />
        </Animated.View>
      </View>
    </Pressable>
  );
}

function GoalAction({
  label,
  onPress,
  disabled = false,
  saving = false,
}: {
  label: string;
  onPress: () => void;
  disabled?: boolean;
  saving?: boolean;
}) {
  const { resolved } = useTheme();
  const palette = goalPalette[resolved];
  const [focus, setFocus] = useState(false);
  const unavailable = disabled || saving;
  const actionLabel = saving ? "Saving goals…" : label;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={actionLabel}
      accessibilityState={{ disabled: unavailable, busy: saving }}
      aria-busy={saving}
      disabled={unavailable}
      onPress={onPress}
      onFocus={() => setFocus(true)}
      onBlur={() => setFocus(false)}
      style={({ pressed }) => [
        styles.action,
        {
          backgroundColor: palette.actionEnd,
          borderColor: focus ? palette.selection : "transparent",
          opacity: disabled ? 0.58 : pressed ? 0.84 : 1,
        },
        artGradient(
          `linear-gradient(160deg, ${palette.actionStart}, ${palette.actionEnd})`,
        ),
      ]}
    >
      {saving ? <ActivityIndicator color="#FFFFFF" /> : null}
      <AppText variant="heading" color="#FFFFFF" style={styles.actionLabel}>
        {actionLabel}
      </AppText>
      {!saving && <Icon name="arrow-forward" color="#FFFFFF" size={19} />}
    </Pressable>
  );
}

function GoalProgress({ step }: { step: 1 | 2 }) {
  const { resolved } = useTheme();
  const palette = goalPalette[resolved];
  return (
    <View
      accessible
      accessibilityLabel={`Step ${step} of 2`}
      style={styles.progress}
    >
      {[1, 2].map((index) => (
        <View
          key={index}
          style={[
            styles.dot,
            {
              backgroundColor:
                index === step ? palette.check : palette.checkBorder,
            },
          ]}
        />
      ))}
    </View>
  );
}

export function WellnessGoalsScreen({
  mode,
  initialGoals,
  onSave,
  onBack,
  onSelectionChange,
}: {
  mode: "onboarding" | "edit";
  initialGoals: readonly WellnessGoal[];
  onSave: (goals: WellnessGoal[]) => Promise<void>;
  onBack?: () => void;
  onSelectionChange?: (goals: WellnessGoal[]) => void;
}) {
  const { colors, resolved } = useTheme();
  const palette = goalPalette[resolved];
  const { width, fontScale } = useWindowDimensions();
  const reduceMotion = useReducedMotion();
  const [selected, setSelected] = useState<ReadonlySet<WellnessGoal>>(
    () => new Set(initialGoals),
  );
  const selectionRef = useRef(selected);
  const [saved, setSaved] = useState<ReadonlySet<WellnessGoal>>(
    () => new Set(initialGoals),
  );
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ text: string; error: boolean }>();
  const savingRef = useRef(false);
  const leavingRef = useRef(false);
  const editing = mode === "edit";
  const changed =
    selected.size !== saved.size || [...selected].some((id) => !saved.has(id));
  const disabled = editing ? !changed : selected.size === 0;
  const artWidth = fontScale > 1.35 || width < 360 ? 70 : 96;
  const goBack = useGuardedBack(onBack);
  useTabResetGuard(saving, "saving");

  async function save() {
    if (
      savingRef.current ||
      leavingRef.current ||
      disabled ||
      (!editing && selectionRef.current.size === 0)
    )
      return;
    savingRef.current = true;
    setMessage(undefined);
    setSaving(true);
    const submitted = selectedIds(selectionRef.current);
    try {
      await onSave(submitted);
      setSaved(new Set(submitted));
      if (editing) setMessage({ text: "Goals saved.", error: false });
    } catch (error) {
      setMessage({
        text:
          error instanceof Error && error.message
            ? error.message
            : "Couldn’t save your goals. Please try again.",
        error: true,
      });
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  }

  function toggle(id: WellnessGoal) {
    if (savingRef.current || leavingRef.current) return;
    void playHaptic("selection");
    setMessage(undefined);
    const next = new Set(selectionRef.current);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    selectionRef.current = next;
    setSelected(next);
    onSelectionChange?.(selectedIds(next));
  }

  return (
    <GoalCanvas
      screenId={editing ? "wellness-goals-editor" : "wellness-goals-onboarding"}
    >
      {editing && onBack && (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Go back"
          accessibilityState={{ disabled: saving }}
          disabled={saving}
          onPress={() => {
            if (savingRef.current || leavingRef.current) return;
            leavingRef.current = true;
            goBack();
          }}
          style={({ pressed }) => [
            styles.back,
            {
              backgroundColor: palette.card,
              borderColor: palette.border,
              opacity: pressed || saving ? 0.6 : 1,
            },
          ]}
        >
          <Icon name="arrow-back" size={21} color={palette.text} />
        </Pressable>
      )}
      <GoalBrand />
      <GoalIntro
        title={editing ? "Your Wellness Goals" : "What brings you here?"}
      >
        {editing
          ? "Choose the goals that matter to you now."
          : "Choose one or more goals. We’ll personalize your experience around what matters to you."}
      </GoalIntro>
      <View style={styles.goalList}>
        {goals.map((goal) => (
          <GoalCard
            key={goal.id}
            goal={goal}
            checked={selected.has(goal.id)}
            disabled={saving}
            reduceMotion={reduceMotion}
            artWidth={artWidth}
            onPress={() => toggle(goal.id)}
          />
        ))}
      </View>
      <View style={styles.footer}>
        {message && (
          <AppText
            accessibilityRole={message.error ? "alert" : undefined}
            accessibilityLiveRegion="polite"
            variant="caption"
            color={message.error ? colors.danger : palette.text}
            style={[
              styles.message,
              { backgroundColor: palette.card, borderColor: palette.border },
            ]}
          >
            {message.text}
          </AppText>
        )}
        <GoalAction
          label={editing ? "Save goals" : "Continue"}
          disabled={disabled}
          saving={saving}
          onPress={() => void save()}
        />
        {!editing && (
          <>
            <AppText
              variant="caption"
              color={palette.text}
              style={styles.footerCopy}
            >
              You can always change your goals later in Profile.
            </AppText>
            <GoalProgress step={1} />
          </>
        )}
      </View>
    </GoalCanvas>
  );
}

export function WellnessGoalsWelcome({
  recommendation,
  onStart,
  onDone,
}: {
  recommendation: {
    title: string;
    description: string;
    actionLabel: string;
    goal: WellnessGoal;
  };
  onStart: () => void;
  onDone: () => void;
}) {
  const { resolved } = useTheme();
  const palette = goalPalette[resolved];
  const opening = useRef(false);
  const option =
    goals.find(({ id }) => id === recommendation.goal) ?? exploreGoal;
  function open(action: () => void) {
    if (opening.current) return;
    opening.current = true;
    action();
  }
  return (
    <GoalCanvas welcome screenId="wellness-goals-welcome">
      <GoalBrand />
      <GoalIntro title="Your space, your pace.">
        Here’s one small step to get started.
      </GoalIntro>
      <View
        style={[
          styles.recommendation,
          { backgroundColor: palette.card, borderColor: palette.border },
        ]}
      >
        <Image
          source={goalImage(option, resolved === "dark")}
          accessible={false}
          accessibilityIgnoresInvertColors
          fadeDuration={0}
          resizeMode="cover"
          style={styles.welcomeImage}
        />
        <View style={styles.recommendationCopy}>
          <AppText
            accessibilityRole="header"
            variant="heading"
            color={palette.text}
          >
            {recommendation.title}
          </AppText>
          <AppText color={palette.muted}>{recommendation.description}</AppText>
        </View>
      </View>
      <View style={styles.footer}>
        <GoalAction
          label={recommendation.actionLabel}
          onPress={() => open(onStart)}
        />
        <Pressable
          accessibilityRole="button"
          onPress={() => open(onDone)}
          style={({ pressed }) => [
            styles.secondary,
            { opacity: pressed ? 0.72 : 1 },
          ]}
        >
          <AppText variant="label" color={palette.text} style={styles.center}>
            Continue to Today
          </AppText>
        </Pressable>
        <GoalProgress step={2} />
      </View>
    </GoalCanvas>
  );
}

const styles = StyleSheet.create({
  canvas: { flex: 1 },
  imageFill: {
    ...StyleSheet.absoluteFill,
    width: "100%",
    height: "100%",
  },
  scroll: {
    flexGrow: 1,
    alignItems: "center",
    paddingTop: 16,
    paddingBottom: 22,
  },
  welcomeScroll: { justifyContent: "center" },
  column: { width: "100%", maxWidth: 460 },
  brand: { alignItems: "center" },
  wordmark: { fontSize: 30, lineHeight: 33, letterSpacing: -0.6 },
  intro: { alignItems: "center", marginTop: 24, marginBottom: 19, gap: 5 },
  title: {
    fontSize: 35,
    lineHeight: Platform.OS === "android" ? 43 : 39,
    letterSpacing: -0.6,
    textAlign: "center",
  },
  introDescription: { width: "100%", alignItems: "center" },
  captionVeil: {
    position: "absolute",
    top: -9,
    bottom: -9,
    start: -20,
    end: -20,
  },
  introCopy: {
    textAlign: "center",
    fontSize: 14,
    lineHeight: 20,
    maxWidth: 375,
  },
  goalList: { gap: 8 },
  goalCard: {
    position: "relative",
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingEnd: 12,
    paddingVertical: 6,
    minHeight: 64,
    borderWidth: 1.25,
    borderRadius: 19,
    overflow: "hidden",
  },
  goalArt: { position: "absolute", top: 0, bottom: 0, start: 0 },
  goalCopy: { flex: 1, minWidth: 0 },
  goalTitle: {
    fontSize: 22,
    lineHeight: Platform.OS === "android" ? 26 : 24,
    letterSpacing: -0.3,
  },
  goalDescription: { fontSize: 12.5, lineHeight: 16.5 },
  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 1.25,
    overflow: "hidden",
  },
  checkboxMark: {
    position: "absolute",
    inset: 0,
    alignItems: "center",
    justifyContent: "center",
  },
  back: {
    position: "absolute",
    top: 0,
    start: 0,
    zIndex: 1,
    alignItems: "center",
    justifyContent: "center",
    width: 48,
    height: 48,
    borderRadius: 24,
    borderWidth: 1,
  },
  footer: { marginTop: 21, marginHorizontal: 10, gap: 10 },
  action: {
    borderRadius: 32,
    borderWidth: 2,
    minHeight: 48,
    paddingVertical: 6,
    paddingHorizontal: 16,
    flexDirection: "row",
    gap: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  actionLabel: {
    textAlign: "center",
    flexShrink: 1,
    fontSize: 23,
    lineHeight: Platform.OS === "android" ? 30 : 27,
  },
  message: {
    textAlign: "center",
    borderWidth: 1,
    borderRadius: 12,
    paddingVertical: 7,
    paddingHorizontal: 12,
  },
  footerCopy: { textAlign: "center", fontSize: 12, lineHeight: 18 },
  progress: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 7,
    marginTop: 2,
  },
  dot: { width: 7, height: 7, borderRadius: 4 },
  recommendation: { borderWidth: 1, borderRadius: 22, overflow: "hidden" },
  welcomeImage: { width: "100%", height: 183 },
  recommendationCopy: { gap: 3, paddingHorizontal: 17, paddingVertical: 13 },
  secondary: {
    minHeight: 48,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 12,
  },
  center: { textAlign: "center" },
});
