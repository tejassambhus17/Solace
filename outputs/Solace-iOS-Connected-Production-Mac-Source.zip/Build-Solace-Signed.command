#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
exec > >(tee ios-build.log) 2>&1
trap 'printf "%s\n" "$?" > ios-build-status.txt' EXIT
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
export LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
export EXPO_NO_DOTENV=1 EXPO_NO_TELEMETRY=1 EXPO_PUBLIC_SOLACE_USB_QA=0
export EXPO_PUBLIC_API_URL=https://solace-demo-240e1d22-d2e6b3cahbheh2ed.centralindia-01.azurewebsites.net
node_runtime=$(node -p "require('./scripts/tooling.cjs').selectRuntime()")
export PATH="$(dirname "$node_runtime"):$PATH"
xcodebuild -version
previous=/Users/tejas/Solace-iOS-Production.eT0Ok5
device=00008130-0012214C247A8D3A

if [[ ! -d node_modules ]]; then
  if [[ -d "$previous/node_modules" ]] && cmp -s package-lock.json "$previous/package-lock.json"; then
    cp -cR "$previous/node_modules" node_modules
  else
    node scripts/runtime.cjs npm ci
  fi
fi

if [[ ! -d ios ]]; then
  if [[ -f "$previous/ios/Pods/Manifest.lock" ]] && cmp -s package-lock.json "$previous/package-lock.json" && cmp -s app.json "$previous/app.json"; then
    cp -cR "$previous/ios" ios
    (cd ios && pod install --deployment)
    cmp ios/Podfile.lock ios/Pods/Manifest.lock
  else
    node scripts/runtime.cjs expo prebuild --platform ios
  fi
fi

node scripts/runtime.cjs expo run:ios --configuration Release --device "$device" --no-bundler --no-install --output signed-ios || echo 'Checking whether the build produced a signed app.'
app="$(find signed-ios -maxdepth 2 -type d -name Solace.app -print -quit)"
test -n "$app"
codesign --verify --deep --strict "$app"
test "$(plutil -extract CFBundleIdentifier raw "$app/Info.plist")" = com.solacewellness.app
for marker in "$EXPO_PUBLIC_API_URL" 'What helped me' 'What brings you here?' 'Your weekly intention' 'X-Solace-Practice-Handoff'; do
  grep -aFq "$marker" "$app/main.jsbundle"
done
test -f "$app/embedded.mobileprovision"
printf 'Provisioning expires: '
security cms -D -i "$app/embedded.mobileprovision" | plutil -extract ExpirationDate raw -o - -
mkdir -p Payload
test ! -e Payload/Solace.app
ditto "$app" Payload/Solace.app
codesign --verify --deep --strict Payload/Solace.app
ditto -c -k --keepParent Payload Solace-iOS-Connected-Production-Device.ipa
unzip -tq Solace-iOS-Connected-Production-Device.ipa
shasum -a 256 Solace-iOS-Connected-Production-Device.ipa > ios-ipa.sha256
cat ios-ipa.sha256
if xcrun devicectl device install app --device "$device" "$app" > ios-device-install.txt 2>&1; then
  echo 'Physical iPhone install passed.'
  if xcrun devicectl device process launch --device "$device" com.solacewellness.app > ios-device-launch.txt 2>&1; then
    echo 'Physical iPhone launch passed.'
  else
    echo 'Physical iPhone launch needs device attention.'
  fi
else
  echo 'IPA verified. Physical device installation could not be verified.'
fi
