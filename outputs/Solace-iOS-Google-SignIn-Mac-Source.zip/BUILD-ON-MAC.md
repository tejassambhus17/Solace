# Solace iPhone release source

This source contains the Google sign-in return fix and the previous Companion, mixer, reminder, navigation, and appearance changes. The build connects to the production Solace Azure HTTPS API.

On the Mac, open Terminal in the extracted folder. Use Xcode 26.4 or later and the Node version in `.node-version`. Sign into the existing Apple Personal Team under Xcode settings. Connect and trust the iPhone and enable Developer Mode.

Run `bash scripts/build-ios-azure.sh`. Select the connected iPhone when Expo prompts. If signing needs setup, select the existing Personal Team under Signing & Capabilities in the generated Solace workspace and rerun the command from the Mac's logged-in desktop session.

The command builds and installs a signed Release build on the selected iPhone. To copy the built app to a folder as well, run `bash scripts/build-ios-azure.sh --output signed-ios`.
