import React, { useEffect, useMemo, useState } from "react";
import {
  Animated,
  Easing,
  Image,
  Platform,
  StyleSheet,
  View,
} from "react-native";
import type { RealtimeAudioLevels } from "../realtime-rtc";
import { artGradient, useTheme } from "../theme";

const twilight = require("../../assets/voice-companion-night.jpg");
const sunrise = require("../../assets/voice-companion-dawn.jpg");
const waveform = [2, 3, 4, 7, 11, 17, 25, 34, 25, 17, 11, 7, 4, 3, 2];
const nativeDriver = Platform.OS !== "web";
type Signal = keyof RealtimeAudioLevels;
const lightStrength = {
  resting: 0,
  connecting: 0.53,
  reconnecting: 0.38,
  listening: 0.58,
  thinking: 0.32,
  speaking: 0.85,
  muted: 0.14,
} as const;
type LotusMotion = keyof typeof lightStrength;

export function useVoiceLevel(
  signal: Signal | undefined,
  read: () => Promise<RealtimeAudioLevels>,
  paused: boolean,
) {
  const [level] = useState(() => new Animated.Value(0));
  const latest = React.useRef(read);
  latest.current = read;
  useEffect(() => {
    let cancelled = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    level.setValue(0);
    if (!signal || paused) return;
    let target = 0;
    const sample = async () => {
      const reading = await latest
        .current()
        .catch(() => ({}) as RealtimeAudioLevels);
      if (cancelled) return;
      const amplitude = reading[signal];
      const next =
        typeof amplitude === "number" && Number.isFinite(amplitude)
          ? Math.min(1, Math.sqrt(Math.max(0, amplitude)) * 2.3)
          : 0;
      if (target !== next) {
        target = next;
        Animated.timing(level, {
          toValue: next,
          duration: 130,
          useNativeDriver: nativeDriver,
          isInteraction: false,
        }).start();
      }
      timer = setTimeout(sample, 140);
    };
    void sample();
    return () => {
      cancelled = true;
      clearTimeout(timer);
      level.stopAnimation();
    };
  }, [level, paused, signal]);
  return level;
}

export const VoiceMeter = React.memo(function VoiceMeter({
  level,
  color,
  compact,
  ready,
}: {
  level: Animated.Value;
  color: string;
  compact?: boolean;
  ready?: boolean;
}) {
  return (
    <View
      accessible={false}
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
      pointerEvents="none"
      style={[styles.meter, compact && styles.compactMeter]}
    >
      {waveform.map((height, index) => (
        <Animated.View
          key={index}
          style={{
            width: compact ? 2 : 2.5,
            height: compact ? height * 0.62 : height,
            borderRadius: 2,
            backgroundColor: color,
            opacity: level.interpolate({
              inputRange: [0, 1],
              outputRange: [ready ? 0.68 : 0.32, 1],
            }),
            transform: [
              {
                scaleY: level.interpolate({
                  inputRange: [0, 1],
                  // The connected quiet state holds a stationary silhouette.
                  outputRange: [
                    Math.min(1, Math.max(2 / height, ready ? 0.48 : 0)),
                    1,
                  ],
                }),
              },
            ],
          }}
        />
      ))}
    </View>
  );
});

export const VoiceBackdrop = React.memo(function VoiceBackdrop({
  motion,
  level,
  paused,
}: {
  motion: LotusMotion;
  level: Animated.Value;
  paused: boolean;
}) {
  const { resolved } = useTheme();
  const [frame, setFrame] = useState({ width: 0, height: 0 });

  return (
    <View
      testID="voice-backdrop"
      accessible={false}
      importantForAccessibility="no-hide-descendants"
      accessibilityElementsHidden
      pointerEvents="none"
      onLayout={({
        nativeEvent: {
          layout: { width, height },
        },
      }) => {
        setFrame((prev) =>
          prev.width === width && prev.height === height
            ? prev
            : { width, height },
        );
      }}
      style={styles.backdrop}
    >
      <Image
        source={resolved === "dark" ? twilight : sunrise}
        accessible={false}
        accessibilityIgnoresInvertColors
        fadeDuration={0}
        resizeMode="cover"
        style={styles.artwork}
      />
      {!paused && frame.width > 0 && frame.height > 0 && (
        <LotusLight
          motion={motion}
          level={level}
          frame={frame}
          dark={resolved === "dark"}
        />
      )}
    </View>
  );
});

function LotusLight({
  motion,
  level,
  frame,
  dark,
}: {
  motion: LotusMotion;
  level: Animated.Value;
  frame: { width: number; height: number };
  dark: boolean;
}) {
  const [drift] = useState(() => new Animated.Value(0));
  const [strength] = useState(() => new Animated.Value(0));
  const [ripple] = useState(() => new Animated.Value(0));
  const active = motion !== "resting";
  const speaking = motion === "speaking";

  useEffect(() => {
    if (!active) return;
    drift.setValue(0);
    const soften = Easing.inOut(Easing.sin);
    const cycle = Animated.loop(
      Animated.timing(drift, {
        toValue: 1,
        duration: 5600,
        easing: (position) => soften(1 - Math.abs(2 * position - 1)),
        useNativeDriver: nativeDriver,
        isInteraction: false,
      }),
    );
    cycle.start();
    return () => cycle.stop();
  }, [active, drift]);

  useEffect(() => {
    const change = Animated.timing(strength, {
      toValue: lightStrength[motion],
      duration: 240,
      useNativeDriver: nativeDriver,
      isInteraction: false,
    });
    change.start();
    return () => change.stop();
  }, [motion, strength]);

  useEffect(() => {
    if (!speaking) return;
    ripple.setValue(0);
    const spread = Animated.timing(ripple, {
      toValue: 1,
      duration: 2300,
      easing: Easing.out(Easing.quad),
      useNativeDriver: nativeDriver,
      isInteraction: false,
    });
    spread.start();
    return () => spread.stop();
  }, [ripple, speaking]);

  const lighting = useMemo(() => {
    const energy = Animated.add(
      Animated.multiply(drift, 0.32),
      Animated.multiply(level, 0.48),
    );
    return {
      opacity: Animated.multiply(strength, Animated.add(0.15, energy)),
      scale: Animated.add(
        1,
        Animated.multiply(Animated.multiply(strength, energy), 0.0375),
      ),
      rippleOpacity: ripple.interpolate({
        inputRange: [0, 0.15, 0.65, 1],
        outputRange: [0, 0.32, 0.13, 0],
      }),
      rippleScale: ripple.interpolate({
        inputRange: [0, 1],
        outputRange: [0.84, 1.47],
      }),
    };
  }, [drift, level, ripple, strength]);

  // Both flattened scenes use this same 852 × 1846 canvas and cover crop.
  const zoom = Math.max(frame.width / 852, frame.height / 1846);
  const box = (x: number, y: number, w: number, h: number) => ({
    left: frame.width / 2 + (x - 426 - w / 2) * zoom,
    top: frame.height / 2 + (y - 923 - h / 2) * zoom,
    width: w * zoom,
    height: h * zoom,
  });

  return (
    <>
      <Animated.View
        testID="voice-lotus-halo"
        style={[
          styles.light,
          box(414, 777, 624, 416),
          dark ? styles.nightHalo : styles.dawnHalo,
          { opacity: lighting.opacity, transform: [{ scale: lighting.scale }] },
        ]}
      />
      <Animated.View
        testID="voice-lotus-glow"
        style={[
          styles.light,
          box(426, 915, 448, 218),
          styles.petalGlow,
          { opacity: lighting.opacity, transform: [{ scale: lighting.scale }] },
        ]}
      />
      {speaking && (
        <Animated.View
          testID="voice-lotus-ripple"
          style={[
            styles.light,
            styles.ripple,
            box(426, 1023, 444, 39),
            {
              borderColor: dark ? "#F9C6E4" : "#A568A2",
              opacity: lighting.rippleOpacity,
              transform: [{ scale: lighting.rippleScale }],
            },
          ]}
        />
      )}
    </>
  );
}

const styles = StyleSheet.create({
  meter: {
    height: 36,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
  },
  compactMeter: { height: 24, gap: 5 },
  backdrop: { ...StyleSheet.absoluteFill, overflow: "hidden" },
  artwork: { width: "100%", height: "100%" },
  light: { position: "absolute" },
  petalGlow: artGradient(
    "radial-gradient(ellipse closest-side at center, #FFE4BC91 0%, #FFD4BC54 45%, #EFADDE18 76%, #EFADDE00 100%)",
  ),
  nightHalo: artGradient(
    "radial-gradient(ellipse closest-side at center, #CDA2FF00 64%, #CDA2FF45 85%, #CDA2FF00 100%)",
  ),
  dawnHalo: artGradient(
    "radial-gradient(ellipse closest-side at center, #F8D7F500 64%, #F8D7F56B 85%, #F8D7F500 100%)",
  ),
  ripple: { borderRadius: "50%", borderWidth: StyleSheet.hairlineWidth },
});
