import React, { useRef, useState } from "react";
import { Pressable, View } from "react-native";
import { localDay } from "../content";
import { spacing } from "../layout";
import { practiceFollowUpId } from "../practice-follow-up";
import { useApp, type Item } from "../store";
import { useTheme } from "../theme";
import { AppText, Button, Card, moodPetals } from "../ui";

export function PracticeCompletion({ session }: { session: Item }) {
  const app = useApp();
  const { colors } = useTheme();
  const id = practiceFollowUpId(session.id);
  const saved = id && app.data.checkins.find((entry) => entry.id === id);
  const [open, setOpen] = useState(false);
  const [skipped, setSkipped] = useState(false);
  const [mood, setMood] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const submission = useRef<Item | undefined>(undefined);
  const locked = useRef(false);
  const seconds = Math.max(0, Math.floor(Number(session.durationSec) || 0));
  const minutes = Math.floor(seconds / 60);
  const duration = minutes
    ? `${minutes} min${seconds % 60 ? ` ${seconds % 60} sec` : ""}`
    : `${seconds} sec`;

  async function saveMood() {
    if (!id || !mood || locked.current || saved) return;
    locked.current = true;
    setSaving(true);
    setError("");
    const now = new Date();
    submission.current ??= {
      id,
      mood,
      tags: [],
      note: "",
      day: localDay(now),
      createdAt: now.toISOString(),
    };
    try {
      await app.save("checkins", submission.current);
    } catch {
      setError(
        "Your check-in couldn’t be confirmed. Retry to save the same response.",
      );
    } finally {
      locked.current = false;
      setSaving(false);
    }
  }

  return (
    <Card style={{ gap: spacing.compact }}>
      <AppText accessibilityRole="header" variant="heading">
        {session.title || "Practice complete"}
      </AppText>
      <AppText color={colors.muted}>
        {duration} of active time · Saved to Journey
      </AppText>
      {saved ? (
        <AppText accessibilityLiveRegion="polite" color={colors.sageText}>
          {saved.localOnly
            ? "Check-in saved on this device · Waiting to sync"
            : `Check-in saved · ${saved.mood}`}
        </AppText>
      ) : id && !skipped ? (
        <>
          {open ? (
            <>
              <AppText variant="label">How are you feeling now?</AppText>
              <View
                accessibilityRole="radiogroup"
                accessibilityLabel="Mood after practice"
                style={{
                  flexDirection: "row",
                  flexWrap: "wrap",
                  gap: spacing.compact,
                }}
              >
                {moodPetals.map((choice) => (
                  <Pressable
                    key={choice.mood}
                    accessibilityRole="radio"
                    accessibilityState={{
                      checked: mood === choice.mood,
                      disabled: !!submission.current,
                    }}
                    disabled={!!submission.current}
                    onPress={() => setMood(choice.mood)}
                    style={({ pressed }) => ({
                      paddingHorizontal: spacing.row,
                      minHeight: 48,
                      justifyContent: "center",
                      borderWidth: 1,
                      borderRadius: 24,
                      borderColor: colors.border,
                      backgroundColor:
                        mood === choice.mood ? colors.primary : colors.surface,
                      opacity: pressed ? 0.75 : 1,
                    })}
                  >
                    <AppText
                      color={
                        mood === choice.mood ? colors.primaryText : colors.text
                      }
                    >
                      {choice.mood}
                    </AppText>
                  </Pressable>
                ))}
              </View>
              {!!error && (
                <AppText accessibilityRole="alert" color={colors.danger}>
                  {error}
                </AppText>
              )}
              <Button
                title={error ? "Retry check-in" : "Save check-in"}
                onPress={() => void saveMood()}
                disabled={!mood}
                loading={saving}
              />
            </>
          ) : (
            <Button
              title="Check in after this practice"
              variant="secondary"
              onPress={() => setOpen(true)}
            />
          )}
          <Button
            title="Skip check-in"
            variant="ghost"
            disabled={saving}
            onPress={() => setSkipped(true)}
          />
        </>
      ) : null}
    </Card>
  );
}
