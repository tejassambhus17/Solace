import { isRecordId } from "./routes";

// The existing check-in API accepts client IDs. A reserved ID ties a response
// to its practice without creating a second mood record on retries.
export function practiceFollowUpId(sessionId: unknown) {
  if (!isRecordId(sessionId) || !sessionId.startsWith("moment-session-"))
    return undefined;
  const id = `after-${sessionId}`;
  return isRecordId(id) ? id : undefined;
}

export const isPracticeFollowUpId = (id: unknown) =>
  typeof id === "string" &&
  practiceFollowUpId(id.slice("after-".length)) === id;
