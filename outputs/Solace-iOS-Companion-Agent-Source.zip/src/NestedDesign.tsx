import React, { type ReactNode } from "react";
import {
  Image,
  StyleSheet,
  View,
  type ImageSourcePropType,
  type StyleProp,
  type ViewStyle,
} from "react-native";
import { spacing } from "./layout";
import { artGradient, useTheme } from "./theme";
import { AppText, coverImageStyle } from "./ui";

type SceneTone = "lavender" | "sage" | "peach";

export function SceneIntro({
  image,
  title,
  description,
  meta,
  children,
  tone = "lavender",
  style,
}: {
  image: ImageSourcePropType;
  title: string;
  description?: string;
  meta?: string;
  children?: ReactNode;
  tone?: SceneTone;
  style?: StyleProp<ViewStyle>;
}) {
  const { colors, resolved } = useTheme();
  const surface = colors[`${tone}Surface`];
  return (
    <View
      style={[
        styles.scene,
        { backgroundColor: surface, borderColor: colors.border },
        style,
      ]}
    >
      <View pointerEvents="none" style={styles.sceneArtwork}>
        <Image
          source={image}
          resizeMode="cover"
          resizeMethod="resize"
          fadeDuration={0}
          accessible={false}
          style={coverImageStyle}
        />
        <View
          style={[
            StyleSheet.absoluteFill,
            artGradient(
              `linear-gradient(180deg, transparent 22%, ${surface}55 53%, ${surface} 100%)`,
            ),
          ]}
        />
      </View>
      <View style={styles.sceneContent}>
        <AppText
          variant="display"
          accessibilityRole="header"
          style={styles.sceneTitle}
        >
          {title}
        </AppText>
        {description && (
          <AppText color={colors.text} style={styles.sceneDescription}>
            {description}
          </AppText>
        )}
        {meta && (
          <AppText
            variant="label"
            color={resolved === "dark" ? colors[`${tone}Text`] : colors.text}
          >
            {meta}
          </AppText>
        )}
        {children}
      </View>
    </View>
  );
}

export function EditorialSection({
  title,
  description,
}: {
  title: string;
  description?: string;
}) {
  const { colors } = useTheme();
  return (
    <View style={styles.section}>
      <AppText
        variant="heading"
        accessibilityRole="header"
        style={styles.sectionTitle}
      >
        {title}
      </AppText>
      {description && <AppText color={colors.muted}>{description}</AppText>}
    </View>
  );
}

const styles = StyleSheet.create({
  scene: {
    borderWidth: 1,
    borderRadius: 24,
    overflow: "hidden",
    marginBottom: spacing.section,
  },
  sceneArtwork: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: 142,
  },
  sceneContent: {
    paddingTop: 100,
    paddingHorizontal: spacing.card + 4,
    paddingBottom: spacing.card + 4,
    gap: spacing.compact,
  },
  sceneTitle: { fontSize: 38, lineHeight: 41 },
  sceneDescription: { fontSize: 14, lineHeight: 21 },
  section: { gap: 4, marginBottom: spacing.row },
  sectionTitle: { fontSize: 27, lineHeight: 31 },
});
