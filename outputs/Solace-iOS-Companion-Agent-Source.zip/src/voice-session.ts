export type VoiceState =
  "idle" | "preparing" | "listening" | "transcribing" | "cancelling";
export const MAX_VOICE_BYTES = 8 * 1024 * 1024;

export type VoiceIO = {
  permission: () => Promise<boolean | "away">;
  start: () => Promise<void>;
  stop: () => Promise<ArrayBuffer>;
  cancel: () => Promise<void>;
  transcribe: (audio: ArrayBuffer, signal: AbortSignal) => Promise<string>;
  transcript: (text: string) => void;
  changed: (state: VoiceState, error: string) => void;
};

/** A turn is scoped to its mounted account/conversation. No automatic send. */
export class VoiceTurn {
  private version = 0;
  private disposed = false;
  private audio: ArrayBuffer | null = null;
  private permissionVersion: number | null = null;
  private starting: Promise<void> | null = null;
  private stopping: Promise<ArrayBuffer> | null = null;
  private cancelling: Promise<void> | null = null;
  private transcription: AbortController | null = null;
  state: VoiceState = "idle";
  constructor(private io: VoiceIO) {}
  private publish(state: VoiceState, error = "") {
    if (this.disposed) return;
    this.state = state;
    this.io.changed(state, error);
  }
  private current(version: number) {
    return !this.disposed && this.version === version;
  }
  async start() {
    if (this.disposed || this.state !== "idle") return;
    const version = ++this.version;
    this.audio = null;
    this.publish("preparing");
    try {
      this.permissionVersion = version;
      let permission: Awaited<ReturnType<VoiceIO["permission"]>>;
      try {
        permission = await this.io.permission();
      } finally {
        if (this.permissionVersion === version) this.permissionVersion = null;
      }
      if (!this.current(version)) return;
      if (permission !== true) {
        this.publish(
          "idle",
          permission === "away"
            ? "Tap the microphone when you're ready to record."
            : "Microphone access is off. Allow it in device settings, or type your message.",
        );
        return;
      }
      const starting = this.io.start();
      this.starting = starting;
      try {
        await starting;
      } finally {
        if (this.starting === starting) this.starting = null;
      }
      // cancel() owns cleanup and waits for start to settle before releasing
      // the recorder. A stale start must never cancel a newer recording.
      if (!this.current(version)) return;
      this.publish("listening");
    } catch {
      if (this.current(version))
        await this.cancel(
          "Recording could not start. Try again, or type your message.",
        );
    }
  }
  async stop() {
    if (this.disposed || this.state !== "listening") return;
    const version = this.version;
    this.publish("transcribing");
    try {
      const stopping = this.io.stop();
      this.stopping = stopping;
      let audio: ArrayBuffer;
      try {
        audio = await stopping;
      } finally {
        if (this.stopping === stopping) this.stopping = null;
      }
      if (!this.current(version)) return;
      if (audio.byteLength < 45 || audio.byteLength > MAX_VOICE_BYTES)
        throw new Error(
          "The recording was empty or too large. Record a shorter message, up to one minute.",
        );
      this.audio = audio;
      await this.convert(version);
    } catch (error) {
      if (this.current(version))
        await this.cancel(
          error instanceof Error
            ? error.message
            : "Could not read the recording. Please try again.",
        );
    }
  }
  async retry() {
    if (this.disposed || this.state !== "idle" || !this.audio) return;
    this.publish("transcribing");
    await this.convert(this.version);
  }
  async recorderEvent(event: {
    hasError?: boolean;
    isFinished?: boolean;
    mediaServicesDidReset?: boolean;
  }) {
    if (this.disposed || this.state === "idle" || this.state === "cancelling")
      return;
    if (event.hasError || event.mediaServicesDidReset) {
      await this.cancel(
        "Recording was interrupted. Please try again, or type your message.",
      );
    } else if (event.isFinished) {
      await this.stop();
    }
  }
  private async convert(version: number) {
    const controller = new AbortController();
    this.transcription = controller;
    try {
      const text = (
        await this.io.transcribe(this.audio!, controller.signal)
      ).trim();
      if (!this.current(version)) return;
      if (!text || text.length > 4000)
        throw new Error(
          "We couldn't make out a message. Please try a shorter recording or type instead.",
        );
      this.audio = null;
      this.io.transcript(text);
      this.publish("idle");
    } catch (error) {
      if (this.current(version))
        this.publish(
          "idle",
          error instanceof Error
            ? error.message
            : "Transcription failed. Retry, or type your message.",
        );
    } finally {
      if (this.transcription === controller) this.transcription = null;
    }
  }
  get canRetry() {
    return !!this.audio && this.state === "idle";
  }
  leaveForeground() {
    // Permission sheets can temporarily hide the app before any audio starts.
    if (this.permissionVersion === this.version) return;
    if (this.state === "idle" && !this.canRetry) return;
    return this.cancel(
      this.state === "transcribing"
        ? "Transcription was interrupted when you left the app. Try recording again, or type your message."
        : "Recording was discarded when you left the app. Start again when you're ready.",
    );
  }
  cancel(message = ""): Promise<void> {
    if (this.cancelling) return this.cancelling;
    const version = ++this.version;
    this.transcription?.abort();
    this.audio = null;
    this.publish("cancelling");
    const starting = this.starting;
    const stopping = this.stopping;
    this.cancelling = (async () => {
      await Promise.allSettled([starting, stopping]);
      await this.io.cancel().catch(() => {});
      if (this.current(version)) this.publish("idle", message);
    })().finally(() => {
      this.cancelling = null;
    });
    return this.cancelling;
  }
  dispose() {
    this.disposed = true;
    void this.cancel();
  }
}

export function voiceContentType(platform: string, uri = "") {
  if (/\.wav(?:$|\?)/i.test(uri)) return "audio/wav";
  return platform === "web" ? "audio/webm" : "audio/mp4";
}

export function voiceMeterLevel(decibels: number | undefined): number | null {
  if (decibels === -Infinity) return 0;
  if (decibels === undefined || !Number.isFinite(decibels)) return null;
  return Math.min(1, Math.max(0, (decibels + 55) / 55));
}
