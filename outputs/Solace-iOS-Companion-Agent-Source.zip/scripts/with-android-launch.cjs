const fs = require("node:fs/promises");
const path = require("node:path");
const {
  AndroidConfig,
  withAndroidColors,
  withAndroidColorsNight,
  withAndroidStyles,
  withDangerousMod,
} = require("expo/config-plugins");

const background = "solace_launch_background";
const appTheme = { name: "AppTheme" };
const launchTheme = { name: "Theme.App.SplashScreen", parent: "AppTheme" };
const setColor = (value) => (mod) => {
  mod.modResults = AndroidConfig.Colors.setColorItem(
    AndroidConfig.Resources.buildResourceItem({ name: background, value }),
    mod.modResults,
  );
  return mod;
};

module.exports = (config) => {
  config = withAndroidColors(config, setColor("#FBF0E8"));
  config = withAndroidColorsNight(config, setColor("#000000"));
  config = withAndroidStyles(config, (mod) => {
    const set = (parent, name, value) => {
      mod.modResults = AndroidConfig.Styles.assignStylesValue(mod.modResults, {
        add: true,
        parent,
        name,
        value,
      });
    };
    // The activity switches to AppTheme before creating the React view.
    set(appTheme, "android:windowBackground", `@color/${background}`);
    set(appTheme, "android:windowLightStatusBar", "?attr/isLightTheme");
    set(appTheme, "android:windowLightNavigationBar", "?attr/isLightTheme");
    set(
      launchTheme,
      "android:windowBackground",
      "@drawable/solace_legacy_launch",
    );
    // Android 12+ reads these attributes for its mandatory system splash.
    set(
      launchTheme,
      "android:windowSplashScreenBackground",
      `@color/${background}`,
    );
    set(
      launchTheme,
      "android:windowSplashScreenAnimatedIcon",
      "@drawable/solace_launch_logo",
    );
    return mod;
  });
  return withDangerousMod(config, [
    "android",
    async (mod) => {
      const res = path.join(
        mod.modRequest.platformProjectRoot,
        "app",
        "src",
        "main",
        "res",
      );
      const logoDir = path.join(res, "drawable-nodpi");
      await fs.mkdir(logoDir, { recursive: true });
      await fs.mkdir(path.join(res, "drawable"), { recursive: true });
      await fs.copyFile(
        path.join(
          mod.modRequest.projectRoot,
          "assets",
          "app-icons",
          "solace-android-foreground.png",
        ),
        path.join(logoDir, "solace_launch_logo.png"),
      );
      await fs.writeFile(
        path.join(res, "drawable", "solace_legacy_launch.xml"),
        `<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
  <item android:drawable="@color/${background}" />
  <item android:drawable="@drawable/solace_launch_logo"
    android:width="288dp" android:height="288dp" android:gravity="center" />
</layer-list>\n`,
      );
      return mod;
    },
  ]);
};
