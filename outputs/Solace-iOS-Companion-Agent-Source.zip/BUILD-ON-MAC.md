# Solace iOS release source

This archive contains the source to build Solace for a paired iPhone using the existing Apple Personal Team in Xcode. It includes the Companion action fixes and uses the production Azure HTTPS API.

1. Extract the archive on the Mac. Open Terminal in the extracted folder. Connect and trust the iPhone, enable Developer Mode, and sign into the existing Personal Team in Xcode.
2. Confirm Xcode and the project's supported Node version are installed. Use `xcrun xctrace list devices` to find the paired iPhone hardware UDID.
3. Run `bash scripts/build-ios-azure.sh --device "<iPhone UDID>" --output signed-ios`. Replace the placeholder with the identifier shown in step 2. Passing it explicitly avoids the interactive device picker. The script builds Release, installs the app on the paired iPhone and copies the build to signed-ios.

If Xcode requests signing setup, select the existing Personal Team under Signing & Capabilities in the generated Solace workspace. Run the build from the Mac's logged-in desktop session so Xcode can access the signing key.
