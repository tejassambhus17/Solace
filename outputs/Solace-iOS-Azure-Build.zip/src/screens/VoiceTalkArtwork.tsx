import React, { useEffect, useState } from "react";
import { Animated, Easing, Platform, StyleSheet, View } from "react-native";
import type { RealtimeAudioLevels } from "../realtime-rtc";
import { useTheme } from "../theme";

const twilight = require("../../assets/voice-companion-night.jpg");
const sunrise = require("../../assets/voice-companion-dawn.jpg");
const waveform = [2, 3, 4, 7, 11, 17, 25, 34, 25, 17, 11, 7, 4, 3, 2];
const nativeDriver = Platform.OS !== "web";
type Signal = keyof RealtimeAudioLevels;

export function useVoiceLevel(
  signal: Signal | undefined,
  read: () => Promise<RealtimeAudioLevels>,
  reduced: boolean,
) {
  const [level] = useState(() => new Animated.Value(0));
  const latest = React.useRef(read);
  latest.current = read;
  useEffect(() => {
    let cancelled = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    level.stopAnimation();
    if (!signal || reduced) {
      level.setValue(signal ? 0.26 : 0);
      return;
    }
    const sample = async () => {
      const reading = await latest
        .current()
        .catch(() => ({}) as RealtimeAudioLevels);
      if (cancelled) return;
      const amplitude = reading[signal];
      const next =
        amplitude === undefined
          ? 0.26
          : Math.min(1, Math.sqrt(Math.max(0, amplitude)) * 2.3);
      Animated.timing(level, {
        toValue: next,
        duration: 130,
        useNativeDriver: nativeDriver,
        isInteraction: false,
      }).start();
      timer = setTimeout(sample, 140);
    };
    void sample();
    return () => {
      cancelled = true;
      clearTimeout(timer);
      level.stopAnimation();
    };
  }, [level, reduced, signal]);
  return level;
}

export const VoiceMeter = React.memo(function VoiceMeter({
  level,
  color,
  compact,
  ready,
}: {
  level: Animated.Value;
  color: string;
  compact?: boolean;
  ready?: boolean;
}) {
  return (
    <View
      accessible={false}
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
      pointerEvents="none"
      style={[styles.meter, compact && styles.compactMeter]}
    >
      {waveform.map((height, index) => (
        <Animated.View
          key={index}
          style={{
            width: compact ? 2 : 2.5,
            height: compact ? height * 0.62 : height,
            borderRadius: 2,
            backgroundColor: color,
            opacity: level.interpolate({
              inputRange: [0, 1],
              outputRange: [ready ? 0.68 : 0.32, 1],
            }),
            transform: [
              {
                scaleY: level.interpolate({
                  inputRange: [0, 1],
                  // The connected quiet state holds a stationary silhouette.
                  outputRange: [
                    Math.min(1, Math.max(2 / height, ready ? 0.48 : 0)),
                    1,
                  ],
                }),
              },
            ],
          }}
        />
      ))}
    </View>
  );
});

export const VoiceBackdrop = React.memo(function VoiceBackdrop({
  motion,
  level,
  reduced,
}: {
  motion: "resting" | "listening" | "thinking" | "speaking";
  level: Animated.Value;
  reduced: boolean;
}) {
  const { resolved } = useTheme();
  const [drift] = useState(() => new Animated.Value(0));
  useEffect(() => {
    drift.setValue(0);
    if (reduced || motion === "resting") return;
    const duration = motion === "thinking" ? 4400 : 3400;
    const cycle = Animated.loop(
      Animated.timing(drift, {
        toValue: 1,
        duration,
        easing: (position) =>
          Easing.inOut(Easing.sin)(1 - Math.abs(2 * position - 1)),
        useNativeDriver: nativeDriver,
        isInteraction: false,
      }),
    );
    cycle.start();
    return () => cycle.stop();
  }, [drift, motion, reduced]);

  const scale = reduced
    ? 1
    : Animated.add(
        drift.interpolate({
          inputRange: [0, 1],
          outputRange: [1, motion === "thinking" ? 1.005 : 1.009],
        }),
        level.interpolate({ inputRange: [0, 1], outputRange: [0, 0.006] }),
      );

  return (
    <View
      testID="voice-backdrop"
      accessible={false}
      importantForAccessibility="no-hide-descendants"
      accessibilityElementsHidden
      pointerEvents="none"
      style={styles.backdrop}
    >
      <Animated.Image
        source={resolved === "dark" ? twilight : sunrise}
        accessible={false}
        accessibilityIgnoresInvertColors
        fadeDuration={0}
        resizeMode="cover"
        style={[styles.artwork, { transform: [{ scale }] }]}
      />
    </View>
  );
});

const styles = StyleSheet.create({
  meter: {
    height: 36,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
  },
  compactMeter: { height: 24, gap: 5 },
  backdrop: { ...StyleSheet.absoluteFill, overflow: "hidden" },
  artwork: { width: "100%", height: "100%" },
});
