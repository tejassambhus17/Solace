export type VoiceSessionState = {
  id: string;
  phase:
    | "connecting"
    | "listening"
    | "thinking"
    | "speaking"
    | "support"
    | "disconnected";
  revision: number;
  userSpeaking: boolean;
  expiresAt: number;
  reason?: string;
  support?: string;
  conversationId?: string;
};

export type VoiceConnection = {
  id: string;
  answer: string;
  state: VoiceSessionState;
};

export function realtimeShouldEndOnAppState(
  state: string,
  requestingPermission: boolean,
) {
  // System permission can pause the host activity before capture starts.
  return (
    !requestingPermission && (state === "background" || state === "inactive")
  );
}

export function voiceEndedMessage(reason?: string) {
  switch (reason) {
    case "expired":
      return "This voice session reached its time limit.";
    case "authorization_changed":
      return "Your account or conversation changed. Open chat to continue.";
    case "ended":
      return "Your voice session ended.";
    default:
      return "Voice was disconnected. Try again or continue in chat.";
  }
}
