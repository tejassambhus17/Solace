import { useEffect, useRef, useState } from "react";
import { AppState } from "react-native";
import { interruptAmbientPlayback } from "./audio-focus";
import { createRealtimePeer, realtimePeerAvailable } from "./realtime-rtc";
import {
  realtimeShouldEndOnAppState,
  voiceEndedMessage,
  type VoiceSessionState,
} from "./realtime-voice-state";
import type { useApp } from "./store";

type Peer = Awaited<ReturnType<typeof createRealtimePeer>>;
type Transport = "idle" | "connecting" | "connected" | "reconnecting";
type Api = Pick<
  ReturnType<typeof useApp>,
  "startVoiceSession" | "voiceSessionStatus" | "endVoiceSession" | "refresh"
>;
type Attempt = {
  controller: AbortController;
  api: Api;
  peer?: Peer;
  id?: string;
  conversationId?: string;
  muted: boolean;
  requestingPermission: boolean;
  connectedAt?: number;
  speakerChanging?: boolean;
  timeout?: ReturnType<typeof setTimeout>;
};

function failureMessage(error: unknown) {
  const detail = error as { code?: string; name?: string; message?: string };
  if (
    detail?.name === "NotAllowedError" ||
    detail?.name === "PermissionDeniedError" ||
    detail?.code === "MICROPHONE_DENIED" ||
    /permission|denied|microphone access/i.test(detail?.message || "")
  )
    return "Allow microphone access in device settings, or continue in chat.";
  if (detail?.code?.startsWith("REALTIME_") && detail.message)
    return detail.message;
  if (detail?.code === "CONVERSATION_LIMIT" || detail?.code === "CHAT_BUSY")
    return detail.message || "Open chat to continue.";
  return "Live voice couldn’t connect. Try again or continue in chat.";
}

export function useRealtimeVoice(api: Api, initialConversation?: string) {
  const latestApi = useRef(api);
  latestApi.current = api;
  const attempt = useRef<Attempt | null>(null);
  const stopping = useRef<Promise<string | undefined> | null>(null);
  const conversation = useRef(initialConversation);
  const [transport, setTransport] = useState<Transport>("idle");
  const [state, setState] = useState<VoiceSessionState>();
  const [error, setError] = useState<string>();
  const [muted, setMuted] = useState(false);
  const [ending, setEnding] = useState(false);
  const [connectedAt, setConnectedAt] = useState<number>();
  const [speakerphone, setSpeakerphone] = useState<boolean>();
  const [speakerBusy, setSpeakerBusy] = useState(false);
  const [speakerError, setSpeakerError] = useState<string>();
  const mounted = useRef(true);
  const functions = useRef({ finish });
  functions.current.finish = finish;

  function finish(message?: string, preserveStatus = false) {
    const active = attempt.current;
    if (!active)
      return stopping.current ?? Promise.resolve(conversation.current);
    attempt.current = null;
    clearTimeout(active.timeout);
    active.peer?.close();
    active.controller.abort();
    if (mounted.current) {
      setTransport("idle");
      setMuted(false);
      setConnectedAt(undefined);
      setSpeakerphone(undefined);
      setSpeakerBusy(false);
      setSpeakerError(undefined);
      if (!preserveStatus) setState(undefined);
      if (message) setError(message);
    }
    const id = active.id;
    if (!id) return Promise.resolve(conversation.current);
    if (mounted.current) setEnding(true);
    const stop = (async () => {
      try {
        const ended = await active.api.endVoiceSession(id);
        if (ended.conversationId) conversation.current = ended.conversationId;
      } catch {
        // The server also expires the lease when heartbeats stop.
      }
      void active.api.refresh().catch(() => {});
      return conversation.current;
    })();
    stopping.current = stop;
    void stop.then(() => {
      stopping.current = null;
      if (mounted.current) setEnding(false);
    });
    return stop;
  }

  function observe(active: Attempt, next: VoiceSessionState) {
    if (attempt.current !== active) return false;
    if (next.conversationId) conversation.current = next.conversationId;
    setState((previous) =>
      previous?.id === next.id && previous.revision === next.revision
        ? previous
        : next,
    );
    if (next.phase === "support") {
      void finish(undefined, true);
      return false;
    }
    if (next.phase === "disconnected") {
      void finish(voiceEndedMessage(next.reason));
      return false;
    }
    return true;
  }

  async function start() {
    if (attempt.current || stopping.current) return;
    setError(undefined);
    setState(undefined);
    if (!realtimePeerAvailable()) {
      setError(
        "Live voice needs a supported browser or the native Solace app.",
      );
      return;
    }
    const active: Attempt = {
      api: latestApi.current,
      controller: new AbortController(),
      conversationId: conversation.current,
      muted: false,
      requestingPermission: false,
    };
    attempt.current = active;
    setTransport("connecting");
    setMuted(false);
    const { signal } = active.controller;
    const fail = (message: string) => {
      if (attempt.current === active) void finish(message);
    };
    try {
      interruptAmbientPlayback();
      active.peer = await createRealtimePeer({
        signal,
        onPermissionPrompt(pending) {
          active.requestingPermission = pending;
        },
        onState(next) {
          if (attempt.current !== active) return;
          if (next === "connected") {
            clearTimeout(active.timeout);
            if (active.connectedAt === undefined) {
              active.connectedAt = Date.now();
              setConnectedAt(active.connectedAt);
              if (active.peer?.setSpeakerphone) setSpeakerphone(true);
            }
            setTransport("connected");
          } else if (next === "disconnected") {
            clearTimeout(active.timeout);
            setTransport("reconnecting");
            active.timeout = setTimeout(
              () =>
                fail(
                  "The voice connection was lost. Try again or continue in chat.",
                ),
              5000,
            );
          } else if (next === "failed") {
            fail(
              "The voice connection was lost. Try again or continue in chat.",
            );
          }
        },
      });
      if (signal.aborted) {
        active.peer.close();
        return;
      }
      active.timeout = setTimeout(
        () =>
          fail(
            "Voice took too long to connect. Try again or continue in chat.",
          ),
        24000,
      );
      const connection = await active.api.startVoiceSession(
        active.peer.offer,
        active.conversationId,
        signal,
      );
      active.id = connection.id;
      if (signal.aborted) {
        await active.api.endVoiceSession(connection.id).catch(() => {});
        return;
      }
      if (!observe(active, connection.state)) return;
      await active.peer.acceptAnswer(connection.answer);
      let revision = connection.state.revision;
      while (!signal.aborted) {
        const next = await active.api.voiceSessionStatus(
          connection.id,
          revision,
          signal,
        );
        if (!observe(active, next)) return;
        revision = next.revision;
      }
    } catch (cause) {
      if (!signal.aborted) fail(failureMessage(cause));
    }
  }

  useEffect(() => {
    mounted.current = true;
    if (!attempt.current) {
      setTransport("idle");
      setMuted(false);
      setEnding(!!stopping.current);
      setConnectedAt(undefined);
      setSpeakerphone(undefined);
      setSpeakerBusy(false);
      setSpeakerError(undefined);
    }
    const subscription = AppState.addEventListener("change", (next) => {
      const active = attempt.current;
      if (
        active &&
        realtimeShouldEndOnAppState(next, active.requestingPermission)
      )
        void functions.current.finish(
          "Live voice ended when Solace left the foreground. Tap Retry to start again.",
        );
    });
    return () => {
      mounted.current = false;
      subscription?.remove();
      if (attempt.current) void functions.current.finish();
    };
  }, []);

  return {
    transport,
    state,
    muted,
    ending,
    connectedAt,
    speakerphone,
    speakerBusy,
    speakerError,
    error,
    start,
    finish,
    conversationId: () => conversation.current,
    async readAudioLevels() {
      const active = attempt.current;
      if (!active?.peer) return {};
      const levels = await active.peer.readAudioLevels();
      return attempt.current === active ? levels : {};
    },
    async toggleSpeakerphone() {
      const active = attempt.current;
      if (
        !active?.peer?.setSpeakerphone ||
        active.speakerChanging ||
        speakerphone === undefined
      )
        return;
      active.speakerChanging = true;
      setSpeakerBusy(true);
      setSpeakerError(undefined);
      try {
        const next = !speakerphone;
        const applied = await active.peer.setSpeakerphone(next);
        if (attempt.current !== active) return;
        if (applied) setSpeakerphone(next);
        else setSpeakerError("Couldn’t change the speaker preference.");
      } catch {
        if (attempt.current === active)
          setSpeakerError("Couldn’t change the speaker preference.");
      } finally {
        if (attempt.current === active) {
          active.speakerChanging = false;
          setSpeakerBusy(false);
        }
      }
    },
    toggleMute() {
      const active = attempt.current;
      if (!active?.peer) return;
      active.muted = !active.muted;
      active.peer.setMuted(active.muted);
      setMuted(active.muted);
    },
  };
}
