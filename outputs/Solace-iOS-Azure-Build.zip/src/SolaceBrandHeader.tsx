import React from "react";
import { StyleSheet, type StyleProp, type ViewStyle } from "react-native";
import { AppText, LotusMark, Row } from "./ui";

export function SolaceBrandHeader({
  color,
  style,
}: {
  color?: string;
  style?: StyleProp<ViewStyle>;
}) {
  return (
    <Row style={[styles.lockup, style]}>
      <LotusMark size={30} />
      <AppText
        variant="heading"
        color={color}
        style={styles.wordmark}
        numberOfLines={1}
        maxFontSizeMultiplier={1.5}
        adjustsFontSizeToFit
        minimumFontScale={0.8}
      >
        Solace
      </AppText>
    </Row>
  );
}

const styles = StyleSheet.create({
  lockup: { gap: 6, flexShrink: 1 },
  wordmark: { fontSize: 24, lineHeight: 28, flexShrink: 1 },
});
