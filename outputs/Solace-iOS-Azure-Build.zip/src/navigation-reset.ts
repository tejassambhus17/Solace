import { createContext, useContext, useLayoutEffect } from "react";
import { useApp } from "./store";

export const TabResetGuardContext = createContext<
  ((routeKey: number) => () => void) | null
>(null);

export function useTabResetGuard(dirty: boolean) {
  const { routeKey } = useApp();
  const register = useContext(TabResetGuardContext);
  useLayoutEffect(() => {
    if (dirty) return register?.(routeKey);
  }, [dirty, register, routeKey]);
}
