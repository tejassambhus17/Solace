#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
exec > >(tee ios-final-production.log) 2>&1
trap 'printf "%s\n" "$?" > ios-final-production.status' EXIT

export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
export LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
export EXPO_NO_DOTENV=1 EXPO_NO_TELEMETRY=1 EXPO_PUBLIC_SOLACE_USB_QA=0
export EXPO_PUBLIC_API_URL=https://solace-demo-240e1d22-d2e6b3cahbheh2ed.centralindia-01.azurewebsites.net
device=${1:-00008130-0012214C247A8D3A}
previous="$HOME/Solace-iOS-Connected.vJXJ8G"
ipa=Solace-iOS-Final-Production-Device.ipa

test "$(uname -s)" = Darwin
xcodebuild -version
node_runtime=$(node -p "require('./scripts/tooling.cjs').selectRuntime()")
export PATH="$(dirname "$node_runtime"):$PATH"
node --version

node <<'NODE'
const { createHash } = require('node:crypto');
const { readFileSync } = require('node:fs');
const manifest = JSON.parse(readFileSync('source-manifest.json', 'utf8'));
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
if (sha256(JSON.stringify(manifest.entries)) !== manifest.sha256) throw Error('Source manifest checksum changed');
for (const [file, checksum] of manifest.entries) {
  if (sha256(readFileSync(file)) !== checksum) throw Error(`Source changed: ${file}`);
}
console.log(`Verified frozen source: ${manifest.fileCount} files, SHA256 ${manifest.sha256}`);
NODE

if [[ ! -d node_modules ]]; then
  if [[ -d "$previous/node_modules" ]] && cmp -s package-lock.json "$previous/package-lock.json"; then
    cp -cR "$previous/node_modules" node_modules
  else
    node scripts/runtime.cjs npm ci
  fi
fi

if [[ ! -d ios ]]; then
  if [[ -f "$previous/ios/Pods/Manifest.lock" ]] && cmp -s package-lock.json "$previous/package-lock.json" && cmp -s app.json "$previous/app.json"; then
    cp -cR "$previous/ios" ios
  else
    node scripts/runtime.cjs expo prebuild --platform ios
  fi
fi

if [[ -f "$previous/ios/Podfile.lock" ]] && cmp -s package-lock.json "$previous/package-lock.json" && cmp -s app.json "$previous/app.json"; then
  if ! (cd ios && pod install --deployment); then
    (cd ios && pod install)
  fi
  ruby -ryaml -e 'a,b=ARGV.map { |f| YAML.load_file(f) }; abort("Native dependencies changed") unless a["PODS"] == b["PODS"] && a["DEPENDENCIES"] == b["DEPENDENCIES"]; puts "Pod versions match the prior signed release"' "$previous/ios/Podfile.lock" ios/Podfile.lock
fi
cmp ios/Podfile.lock ios/Pods/Manifest.lock

node scripts/runtime.cjs expo run:ios --configuration Release --device "$device" --no-bundler --no-install --output signed-ios || echo 'Expo returned nonzero. Checking for a newly produced signed app.'
app="$(find signed-ios -maxdepth 2 -type d -name Solace.app -print -quit)"
test -n "$app"
codesign --verify --deep --strict "$app"
test "$(plutil -extract CFBundleIdentifier raw "$app/Info.plist")" = com.solacewellness.app
printf 'iOS app version: '
plutil -extract CFBundleShortVersionString raw "$app/Info.plist"
printf 'iOS build number: '
plutil -extract CFBundleVersion raw "$app/Info.plist"
for marker in "$EXPO_PUBLIC_API_URL" 'What helped me' 'Open journal calendar' 'Weekly intention choices' 'X-Solace-Practice-Handoff'; do
  grep -aFq "$marker" "$app/main.jsbundle"
done
test -f "$app/embedded.mobileprovision"
printf 'Provisioning expires: '
security cms -D -i "$app/embedded.mobileprovision" | plutil -extract ExpirationDate raw -o - -

mkdir Payload
ditto "$app" Payload/Solace.app
codesign --verify --deep --strict Payload/Solace.app
ditto -c -k --keepParent Payload "$ipa"
unzip -tq "$ipa"
shasum -a 256 "$ipa" > ios-ipa.sha256
cat ios-ipa.sha256

if xcrun devicectl device install app --device "$device" "$app" > ios-device-install.txt 2>&1; then
  echo 'Physical iPhone install passed.'
  if xcrun devicectl device process launch --device "$device" com.solacewellness.app > ios-device-launch.txt 2>&1; then
    echo 'Physical iPhone launch passed.'
  else
    echo 'Physical iPhone launch was not verified. See ios-device-launch.txt.'
  fi
else
  echo 'IPA verified. Physical iPhone installation was not verified. See ios-device-install.txt.'
fi
