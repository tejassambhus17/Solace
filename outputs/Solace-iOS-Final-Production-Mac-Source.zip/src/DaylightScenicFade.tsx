import React from "react";
import { Image, StyleSheet } from "react-native";

const alphaFade = require("../assets/daylight-scenic-fade.png");

export function DaylightScenicFade({
  color,
  height,
  inverted = false,
}: {
  color: string;
  height: number;
  inverted?: boolean;
}) {
  return (
    <Image
      source={alphaFade}
      resizeMode="stretch"
      fadeDuration={0}
      style={[
        styles.edge,
        { height, tintColor: color },
        inverted && { transform: [{ scaleY: -1 }] },
      ]}
      pointerEvents="none"
      accessible={false}
      accessibilityIgnoresInvertColors
    />
  );
}

const styles = StyleSheet.create({
  edge: { position: "absolute", bottom: 0, left: 0, width: "100%" },
});
